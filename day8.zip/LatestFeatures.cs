﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Runtime.CompilerServices;
//using System.Text;
//using System.Threading.Tasks;
//using ConsoleApp2;
////Extension Method - which allows us to add new methods into a class without editing the source code of 
////the class ;

///* For eg: if a class has some methods and in future if developers wants to add some more methods but 
// they do not permission of accessing the class*/
//namespace ConsoleApp2
//{
//   public sealed class OldService
//    {

//        public int x = 300;
//        public void Test1()
//        {
//            Console.WriteLine("Test 1 method created :");
//        }
//        public void Test2()
//        {
//            Console.WriteLine("Test 2 method created :");
//        }

        
//    }
//}

