using Microsoft.AspNetCore.Mvc;
using LibraryManagementSystem.Models;
using LibraryManagementSystem.Repositories;

namespace LibraryManagementSystem.Controllers
{
    public class GenresController : Controller
    {
        private readonly IGenreRepository _genreRepository;

        public GenresController(IGenreRepository genreRepository)
        {
            _genreRepository = genreRepository;
        }

        // GET: Genres
        public async Task<IActionResult> Index()
        {
            var genres = await _genreRepository.GetGenresWithBooksAsync();
            return View(genres);
        }

        // GET: Genres/Details/5
        public async Task<IActionResult> Details(int id)
        {
            var genre = await _genreRepository.GetGenreWithBooksAsync(id);
            if (genre == null)
            {
                return NotFound();
            }
            return View(genre);
        }

        // GET: Genres/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Genres/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Name,Description")] Genre genre)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    // Check name uniqueness
                    if (!await _genreRepository.IsNameUniqueAsync(genre.Name))
                    {
                        ModelState.AddModelError("Name", "This genre name already exists.");
                        return View(genre);
                    }

                    await _genreRepository.AddAsync(genre);
                    TempData["SuccessMessage"] = "Genre created successfully!";
                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", "An error occurred while creating the genre: " + ex.Message);
                }
            }
            return View(genre);
        }

        // GET: Genres/Edit/5
        public async Task<IActionResult> Edit(int id)
        {
            var genre = await _genreRepository.GetByIdAsync(id);
            if (genre == null)
            {
                return NotFound();
            }
            return View(genre);
        }

        // POST: Genres/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Name,Description")] Genre genre)
        {
            if (id != genre.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    // Check name uniqueness
                    if (!await _genreRepository.IsNameUniqueAsync(genre.Name, genre.Id))
                    {
                        ModelState.AddModelError("Name", "This genre name already exists.");
                        return View(genre);
                    }

                    await _genreRepository.UpdateAsync(genre);
                    TempData["SuccessMessage"] = "Genre updated successfully!";
                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", "An error occurred while updating the genre: " + ex.Message);
                }
            }
            return View(genre);
        }

        // POST: Genres/Delete/5
        [HttpPost]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var genre = await _genreRepository.GetGenreWithBooksAsync(id);
                if (genre == null)
                {
                    return Json(new { success = false, message = "Genre not found." });
                }

                // Check if genre has books
                if (genre.Books.Any())
                {
                    return Json(new { success = false, message = "Cannot delete genre that has books. Please remove all books first." });
                }

                await _genreRepository.DeleteAsync(id);
                return Json(new { success = true, message = "Genre deleted successfully!" });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = "Error deleting genre: " + ex.Message });
            }
        }

        // AJAX: Get genres list
        [HttpGet]
        public async Task<IActionResult> GetGenres()
        {
            try
            {
                var genres = await _genreRepository.GetGenresWithBooksAsync();
                var result = genres.Select(g => new
                {
                    id = g.Id,
                    name = g.Name,
                    description = g.Description,
                    bookCount = g.Books.Count
                });

                return Json(new { success = true, data = result });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        // AJAX: Search genres
        [HttpGet]
        public async Task<IActionResult> Search(string searchTerm)
        {
            try
            {
                var genres = string.IsNullOrEmpty(searchTerm)
                    ? await _genreRepository.GetGenresWithBooksAsync()
                    : await _genreRepository.SearchGenresAsync(searchTerm);

                var result = genres.Select(g => new
                {
                    id = g.Id,
                    name = g.Name,
                    description = g.Description,
                    bookCount = g.Books.Count
                });

                return Json(new { success = true, data = result });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        // AJAX: Create genre
        [HttpPost]
        public async Task<IActionResult> CreateAjax([FromBody] Genre genre)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    var errors = ModelState
                        .Where(x => x.Value.Errors.Count > 0)
                        .Select(x => new { field = x.Key, message = x.Value.Errors.First().ErrorMessage })
                        .ToArray();

                    return Json(new { success = false, errors = errors });
                }

                // Check name uniqueness
                if (!await _genreRepository.IsNameUniqueAsync(genre.Name))
                {
                    return Json(new { success = false, message = "This genre name already exists." });
                }

                var createdGenre = await _genreRepository.AddAsync(genre);

                var result = new
                {
                    id = createdGenre.Id,
                    name = createdGenre.Name,
                    description = createdGenre.Description,
                    bookCount = 0
                };

                return Json(new { success = true, data = result, message = "Genre created successfully!" });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        // AJAX: Update genre
        [HttpPut]
        public async Task<IActionResult> UpdateAjax([FromBody] Genre genre)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    var errors = ModelState
                        .Where(x => x.Value.Errors.Count > 0)
                        .Select(x => new { field = x.Key, message = x.Value.Errors.First().ErrorMessage })
                        .ToArray();

                    return Json(new { success = false, errors = errors });
                }

                // Check name uniqueness
                if (!await _genreRepository.IsNameUniqueAsync(genre.Name, genre.Id))
                {
                    return Json(new { success = false, message = "This genre name already exists." });
                }

                await _genreRepository.UpdateAsync(genre);
                var updatedGenre = await _genreRepository.GetGenreWithBooksAsync(genre.Id);

                var result = new
                {
                    id = updatedGenre.Id,
                    name = updatedGenre.Name,
                    description = updatedGenre.Description,
                    bookCount = updatedGenre.Books.Count
                };

                return Json(new { success = true, data = result, message = "Genre updated successfully!" });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }
    }
}