using Microsoft.AspNetCore.Mvc;
using LibraryManagementSystem.Models;
using LibraryManagementSystem.Repositories;

namespace LibraryManagementSystem.Controllers
{
    public class AuthorsController : Controller
    {
        private readonly IAuthorRepository _authorRepository;

        public AuthorsController(IAuthorRepository authorRepository)
        {
            _authorRepository = authorRepository;
        }

        // GET: Authors
        public async Task<IActionResult> Index()
        {
            var authors = await _authorRepository.GetAuthorsWithBooksAsync();
            return View(authors);
        }

        // GET: Authors/Details/5
        public async Task<IActionResult> Details(int id)
        {
            var author = await _authorRepository.GetAuthorWithBooksAsync(id);
            if (author == null)
            {
                return NotFound();
            }
            return View(author);
        }

        // GET: Authors/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Authors/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,FirstName,LastName,Email,BirthDate")] Author author)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    // Check email uniqueness
                    if (!string.IsNullOrEmpty(author.Email) && !await _authorRepository.IsEmailUniqueAsync(author.Email))
                    {
                        ModelState.AddModelError("Email", "This email address is already in use.");
                        return View(author);
                    }

                    await _authorRepository.AddAsync(author);
                    TempData["SuccessMessage"] = "Author created successfully!";
                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", "An error occurred while creating the author: " + ex.Message);
                }
            }
            return View(author);
        }

        // GET: Authors/Edit/5
        public async Task<IActionResult> Edit(int id)
        {
            var author = await _authorRepository.GetByIdAsync(id);
            if (author == null)
            {
                return NotFound();
            }
            return View(author);
        }

        // POST: Authors/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,FirstName,LastName,Email,BirthDate")] Author author)
        {
            if (id != author.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    // Check email uniqueness
                    if (!string.IsNullOrEmpty(author.Email) && !await _authorRepository.IsEmailUniqueAsync(author.Email, author.Id))
                    {
                        ModelState.AddModelError("Email", "This email address is already in use.");
                        return View(author);
                    }

                    await _authorRepository.UpdateAsync(author);
                    TempData["SuccessMessage"] = "Author updated successfully!";
                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", "An error occurred while updating the author: " + ex.Message);
                }
            }
            return View(author);
        }

        // POST: Authors/Delete/5
        [HttpPost]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var author = await _authorRepository.GetAuthorWithBooksAsync(id);
                if (author == null)
                {
                    return Json(new { success = false, message = "Author not found." });
                }

                // Check if author has books
                if (author.Books.Any())
                {
                    return Json(new { success = false, message = "Cannot delete author who has books. Please remove all books first." });
                }

                await _authorRepository.DeleteAsync(id);
                return Json(new { success = true, message = "Author deleted successfully!" });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = "Error deleting author: " + ex.Message });
            }
        }

        // AJAX: Get authors list
        [HttpGet]
        public async Task<IActionResult> GetAuthors()
        {
            try
            {
                var authors = await _authorRepository.GetAuthorsWithBooksAsync();
                var result = authors.Select(a => new
                {
                    id = a.Id,
                    firstName = a.FirstName,
                    lastName = a.LastName,
                    fullName = a.FullName,
                    email = a.Email,
                    birthDate = a.BirthDate?.ToString("yyyy-MM-dd"),
                    bookCount = a.Books.Count
                });

                return Json(new { success = true, data = result });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        // AJAX: Search authors
        [HttpGet]
        public async Task<IActionResult> Search(string searchTerm)
        {
            try
            {
                var authors = string.IsNullOrEmpty(searchTerm)
                    ? await _authorRepository.GetAuthorsWithBooksAsync()
                    : await _authorRepository.SearchAuthorsAsync(searchTerm);

                var result = authors.Select(a => new
                {
                    id = a.Id,
                    firstName = a.FirstName,
                    lastName = a.LastName,
                    fullName = a.FullName,
                    email = a.Email,
                    birthDate = a.BirthDate?.ToString("yyyy-MM-dd"),
                    bookCount = a.Books.Count
                });

                return Json(new { success = true, data = result });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        // AJAX: Create author
        [HttpPost]
        public async Task<IActionResult> CreateAjax([FromBody] Author author)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    var errors = ModelState
                        .Where(x => x.Value.Errors.Count > 0)
                        .Select(x => new { field = x.Key, message = x.Value.Errors.First().ErrorMessage })
                        .ToArray();

                    return Json(new { success = false, errors = errors });
                }

                // Check email uniqueness
                if (!string.IsNullOrEmpty(author.Email) && !await _authorRepository.IsEmailUniqueAsync(author.Email))
                {
                    return Json(new { success = false, message = "This email address is already in use." });
                }

                var createdAuthor = await _authorRepository.AddAsync(author);

                var result = new
                {
                    id = createdAuthor.Id,
                    firstName = createdAuthor.FirstName,
                    lastName = createdAuthor.LastName,
                    fullName = createdAuthor.FullName,
                    email = createdAuthor.Email,
                    birthDate = createdAuthor.BirthDate?.ToString("yyyy-MM-dd"),
                    bookCount = 0
                };

                return Json(new { success = true, data = result, message = "Author created successfully!" });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        // AJAX: Update author
        [HttpPut]
        public async Task<IActionResult> UpdateAjax([FromBody] Author author)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    var errors = ModelState
                        .Where(x => x.Value.Errors.Count > 0)
                        .Select(x => new { field = x.Key, message = x.Value.Errors.First().ErrorMessage })
                        .ToArray();

                    return Json(new { success = false, errors = errors });
                }

                // Check email uniqueness
                if (!string.IsNullOrEmpty(author.Email) && !await _authorRepository.IsEmailUniqueAsync(author.Email, author.Id))
                {
                    return Json(new { success = false, message = "This email address is already in use." });
                }

                await _authorRepository.UpdateAsync(author);
                var updatedAuthor = await _authorRepository.GetAuthorWithBooksAsync(author.Id);

                var result = new
                {
                    id = updatedAuthor.Id,
                    firstName = updatedAuthor.FirstName,
                    lastName = updatedAuthor.LastName,
                    fullName = updatedAuthor.FullName,
                    email = updatedAuthor.Email,
                    birthDate = updatedAuthor.BirthDate?.ToString("yyyy-MM-dd"),
                    bookCount = updatedAuthor.Books.Count
                };

                return Json(new { success = true, data = result, message = "Author updated successfully!" });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }
    }
}