using Microsoft.AspNetCore.Mvc;
using LibraryManagementSystem.Repositories;

namespace LibraryManagementSystem.Controllers
{
    public class HomeController : Controller
    {
        private readonly IBookRepository _bookRepository;
        private readonly IAuthorRepository _authorRepository;
        private readonly IGenreRepository _genreRepository;

        public HomeController(
            IBookRepository bookRepository,
            IAuthorRepository authorRepository,
            IGenreRepository genreRepository)
        {
            _bookRepository = bookRepository;
            _authorRepository = authorRepository;
            _genreRepository = genreRepository;
        }

        public async Task<IActionResult> Index()
        {
            ViewBag.BookCount = await _bookRepository.CountAsync();
            ViewBag.AuthorCount = await _authorRepository.CountAsync();
            ViewBag.GenreCount = await _genreRepository.CountAsync();

            var recentBooks = await _bookRepository.GetBooksWithDetailsAsync();
            ViewBag.RecentBooks = recentBooks.Take(5);

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View();
        }
    }
}