using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using LibraryManagementSystem.Models;
using LibraryManagementSystem.Repositories;
using Newtonsoft.Json;

namespace LibraryManagementSystem.Controllers
{
    public class BooksController : Controller
    {
        private readonly IBookRepository _bookRepository;
        private readonly IAuthorRepository _authorRepository;
        private readonly IGenreRepository _genreRepository;

        public BooksController(
            IBookRepository bookRepository,
            IAuthorRepository authorRepository,
            IGenreRepository genreRepository)
        {
            _bookRepository = bookRepository;
            _authorRepository = authorRepository;
            _genreRepository = genreRepository;
        }

        // GET: Books
        public async Task<IActionResult> Index()
        {
            var books = await _bookRepository.GetBooksWithDetailsAsync();
            return View(books);
        }

        // GET: Books/Details/5
        public async Task<IActionResult> Details(int id)
        {
            var book = await _bookRepository.GetBookWithDetailsAsync(id);
            if (book == null)
            {
                return NotFound();
            }
            return View(book);
        }

        // GET: Books/Create
        public async Task<IActionResult> Create()
        {
            await PopulateDropDownLists();
            return View();
        }

        // POST: Books/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Title,ISBN,PublicationYear,AuthorId,GenreId")] Book book)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    // Check ISBN uniqueness
                    if (!await _bookRepository.IsISBNUniqueAsync(book.ISBN))
                    {
                        ModelState.AddModelError("ISBN", "This ISBN already exists.");
                        await PopulateDropDownLists(book.AuthorId, book.GenreId);
                        return View(book);
                    }

                    await _bookRepository.AddAsync(book);
                    TempData["SuccessMessage"] = "Book created successfully!";
                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", "An error occurred while creating the book: " + ex.Message);
                }
            }

            await PopulateDropDownLists(book.AuthorId, book.GenreId);
            return View(book);
        }

        // GET: Books/Edit/5
        public async Task<IActionResult> Edit(int id)
        {
            var book = await _bookRepository.GetByIdAsync(id);
            if (book == null)
            {
                return NotFound();
            }

            await PopulateDropDownLists(book.AuthorId, book.GenreId);
            return View(book);
        }

        // POST: Books/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Title,ISBN,PublicationYear,AuthorId,GenreId")] Book book)
        {
            if (id != book.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    // Check ISBN uniqueness
                    if (!await _bookRepository.IsISBNUniqueAsync(book.ISBN, book.Id))
                    {
                        ModelState.AddModelError("ISBN", "This ISBN already exists.");
                        await PopulateDropDownLists(book.AuthorId, book.GenreId);
                        return View(book);
                    }

                    await _bookRepository.UpdateAsync(book);
                    TempData["SuccessMessage"] = "Book updated successfully!";
                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", "An error occurred while updating the book: " + ex.Message);
                }
            }

            await PopulateDropDownLists(book.AuthorId, book.GenreId);
            return View(book);
        }

        // POST: Books/Delete/5
        [HttpPost]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var book = await _bookRepository.GetByIdAsync(id);
                if (book == null)
                {
                    return Json(new { success = false, message = "Book not found." });
                }

                await _bookRepository.DeleteAsync(id);
                return Json(new { success = true, message = "Book deleted successfully!" });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = "Error deleting book: " + ex.Message });
            }
        }

        // AJAX: Get books list
        [HttpGet]
        public async Task<IActionResult> GetBooks()
        {
            try
            {
                var books = await _bookRepository.GetBooksWithDetailsAsync();
                var result = books.Select(b => new
                {
                    id = b.Id,
                    title = b.Title,
                    isbn = b.ISBN,
                    publicationYear = b.PublicationYear,
                    authorName = b.Author?.FullName,
                    genreName = b.Genre?.Name
                });

                return Json(new { success = true, data = result });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        // AJAX: Search books
        [HttpGet]
        public async Task<IActionResult> Search(string searchTerm)
        {
            try
            {
                var books = string.IsNullOrEmpty(searchTerm)
                    ? await _bookRepository.GetBooksWithDetailsAsync()
                    : await _bookRepository.SearchBooksAsync(searchTerm);

                var result = books.Select(b => new
                {
                    id = b.Id,
                    title = b.Title,
                    isbn = b.ISBN,
                    publicationYear = b.PublicationYear,
                    authorName = b.Author?.FullName,
                    genreName = b.Genre?.Name
                });

                return Json(new { success = true, data = result });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        // AJAX: Create book
        [HttpPost]
        public async Task<IActionResult> CreateAjax([FromBody] Book book)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    var errors = ModelState
                        .Where(x => x.Value.Errors.Count > 0)
                        .Select(x => new { field = x.Key, message = x.Value.Errors.First().ErrorMessage })
                        .ToArray();

                    return Json(new { success = false, errors = errors });
                }

                // Check ISBN uniqueness
                if (!await _bookRepository.IsISBNUniqueAsync(book.ISBN))
                {
                    return Json(new { success = false, message = "This ISBN already exists." });
                }

                var createdBook = await _bookRepository.AddAsync(book);
                var bookWithDetails = await _bookRepository.GetBookWithDetailsAsync(createdBook.Id);

                var result = new
                {
                    id = bookWithDetails.Id,
                    title = bookWithDetails.Title,
                    isbn = bookWithDetails.ISBN,
                    publicationYear = bookWithDetails.PublicationYear,
                    authorName = bookWithDetails.Author?.FullName,
                    genreName = bookWithDetails.Genre?.Name
                };

                return Json(new { success = true, data = result, message = "Book created successfully!" });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        // AJAX: Update book
        [HttpPut]
        public async Task<IActionResult> UpdateAjax([FromBody] Book book)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    var errors = ModelState
                        .Where(x => x.Value.Errors.Count > 0)
                        .Select(x => new { field = x.Key, message = x.Value.Errors.First().ErrorMessage })
                        .ToArray();

                    return Json(new { success = false, errors = errors });
                }

                // Check ISBN uniqueness
                if (!await _bookRepository.IsISBNUniqueAsync(book.ISBN, book.Id))
                {
                    return Json(new { success = false, message = "This ISBN already exists." });
                }

                await _bookRepository.UpdateAsync(book);
                var bookWithDetails = await _bookRepository.GetBookWithDetailsAsync(book.Id);

                var result = new
                {
                    id = bookWithDetails.Id,
                    title = bookWithDetails.Title,
                    isbn = bookWithDetails.ISBN,
                    publicationYear = bookWithDetails.PublicationYear,
                    authorName = bookWithDetails.Author?.FullName,
                    genreName = bookWithDetails.Genre?.Name
                };

                return Json(new { success = true, data = result, message = "Book updated successfully!" });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        private async Task PopulateDropDownLists(object selectedAuthor = null, object selectedGenre = null)
        {
            var authors = await _authorRepository.GetAllAsync();
            var genres = await _genreRepository.GetAllAsync();

            ViewData["AuthorId"] = new SelectList(authors, "Id", "FullName", selectedAuthor);
            ViewData["GenreId"] = new SelectList(genres, "Id", "Name", selectedGenre);
        }
    }
}