using Microsoft.EntityFrameworkCore;
using LibraryManagementSystem.Data;
using LibraryManagementSystem.Models;

namespace LibraryManagementSystem.Repositories
{
    public class AuthorRepository : GenericRepository<Author>, IAuthorRepository
    {
        public AuthorRepository(LibraryContext context) : base(context)
        {
        }

        public async Task<IEnumerable<Author>> GetAuthorsWithBooksAsync()
        {
            return await _dbSet
                .Include(a => a.Books)
                .ThenInclude(b => b.Genre)
                .OrderBy(a => a.LastName)
                .ThenBy(a => a.FirstName)
                .ToListAsync();
        }

        public async Task<Author?> GetAuthorWithBooksAsync(int id)
        {
            return await _dbSet
                .Include(a => a.Books)
                .ThenInclude(b => b.Genre)
                .FirstOrDefaultAsync(a => a.Id == id);
        }

        public async Task<IEnumerable<Author>> SearchAuthorsAsync(string searchTerm)
        {
            return await _dbSet
                .Include(a => a.Books)
                .Where(a => a.FirstName.Contains(searchTerm) ||
                           a.LastName.Contains(searchTerm) ||
                           a.Email.Contains(searchTerm))
                .OrderBy(a => a.LastName)
                .ThenBy(a => a.FirstName)
                .ToListAsync();
        }

        public async Task<bool> IsEmailUniqueAsync(string email, int? excludeAuthorId = null)
        {
            var query = _dbSet.Where(a => a.Email == email);

            if (excludeAuthorId.HasValue)
            {
                query = query.Where(a => a.Id != excludeAuthorId.Value);
            }

            return !await query.AnyAsync();
        }
    }
}