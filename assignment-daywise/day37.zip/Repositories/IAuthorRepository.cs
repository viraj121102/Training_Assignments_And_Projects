using LibraryManagementSystem.Models;

namespace LibraryManagementSystem.Repositories
{
    public interface IAuthorRepository : IGenericRepository<Author>
    {
        Task<IEnumerable<Author>> GetAuthorsWithBooksAsync();
        Task<Author?> GetAuthorWithBooksAsync(int id);
        Task<IEnumerable<Author>> SearchAuthorsAsync(string searchTerm);
        Task<bool> IsEmailUniqueAsync(string email, int? excludeAuthorId = null);
    }
}