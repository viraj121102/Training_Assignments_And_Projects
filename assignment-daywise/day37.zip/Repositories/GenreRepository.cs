using Microsoft.EntityFrameworkCore;
using LibraryManagementSystem.Data;
using LibraryManagementSystem.Models;

namespace LibraryManagementSystem.Repositories
{
    public class GenreRepository : GenericRepository<Genre>, IGenreRepository
    {
        public GenreRepository(LibraryContext context) : base(context)
        {
        }

        public async Task<IEnumerable<Genre>> GetGenresWithBooksAsync()
        {
            return await _dbSet
                .Include(g => g.Books)
                .ThenInclude(b => b.Author)
                .OrderBy(g => g.Name)
                .ToListAsync();
        }

        public async Task<Genre?> GetGenreWithBooksAsync(int id)
        {
            return await _dbSet
                .Include(g => g.Books)
                .ThenInclude(b => b.Author)
                .FirstOrDefaultAsync(g => g.Id == id);
        }

        public async Task<IEnumerable<Genre>> SearchGenresAsync(string searchTerm)
        {
            return await _dbSet
                .Include(g => g.Books)
                .Where(g => g.Name.Contains(searchTerm) ||
                           g.Description.Contains(searchTerm))
                .OrderBy(g => g.Name)
                .ToListAsync();
        }

        public async Task<bool> IsNameUniqueAsync(string name, int? excludeGenreId = null)
        {
            var query = _dbSet.Where(g => g.Name == name);

            if (excludeGenreId.HasValue)
            {
                query = query.Where(g => g.Id != excludeGenreId.Value);
            }

            return !await query.AnyAsync();
        }
    }
}