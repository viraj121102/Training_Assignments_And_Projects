using LibraryManagementSystem.Models;

namespace LibraryManagementSystem.Repositories
{
    public interface IGenreRepository : IGenericRepository<Genre>
    {
        Task<IEnumerable<Genre>> GetGenresWithBooksAsync();
        Task<Genre?> GetGenreWithBooksAsync(int id);
        Task<IEnumerable<Genre>> SearchGenresAsync(string searchTerm);
        Task<bool> IsNameUniqueAsync(string name, int? excludeGenreId = null);
    }
}