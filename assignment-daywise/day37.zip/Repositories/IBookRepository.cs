using LibraryManagementSystem.Models;

namespace LibraryManagementSystem.Repositories
{
    public interface IBookRepository : IGenericRepository<Book>
    {
        Task<IEnumerable<Book>> GetBooksWithDetailsAsync();
        Task<Book?> GetBookWithDetailsAsync(int id);
        Task<IEnumerable<Book>> GetBooksByAuthorAsync(int authorId);
        Task<IEnumerable<Book>> GetBooksByGenreAsync(int genreId);
        Task<IEnumerable<Book>> SearchBooksAsync(string searchTerm);
        Task<bool> IsISBNUniqueAsync(string isbn, int? excludeBookId = null);
    }
}