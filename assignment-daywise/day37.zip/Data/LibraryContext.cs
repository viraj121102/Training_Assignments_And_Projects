using Microsoft.EntityFrameworkCore;
using LibraryManagementSystem.Models;

namespace LibraryManagementSystem.Data
{
    public class LibraryContext : DbContext
    {
        public LibraryContext(DbContextOptions<LibraryContext> options) : base(options)
        {
        }

        public DbSet<Book> Books { get; set; }
        public DbSet<Author> Authors { get; set; }
        public DbSet<Genre> Genres { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configure relationships
            modelBuilder.Entity<Book>()
                .HasOne(b => b.Author)
                .WithMany(a => a.Books)
                .HasForeignKey(b => b.AuthorId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Book>()
                .HasOne(b => b.Genre)
                .WithMany(g => g.Books)
                .HasForeignKey(b => b.GenreId)
                .OnDelete(DeleteBehavior.Restrict);

            // Configure unique constraints
            modelBuilder.Entity<Book>()
                .HasIndex(b => b.ISBN)
                .IsUnique();

            modelBuilder.Entity<Author>()
                .HasIndex(a => a.Email)
                .IsUnique();

            // Seed data
            SeedData(modelBuilder);
        }

        private static void SeedData(ModelBuilder modelBuilder)
        {
            // Seed Authors
            modelBuilder.Entity<Author>().HasData(
                new Author { Id = 1, FirstName = "J.K.", LastName = "Rowling", Email = "jk.rowling@email.com", BirthDate = new DateTime(1965, 7, 31) },
                new Author { Id = 2, FirstName = "George", LastName = "Orwell", Email = "g.orwell@email.com", BirthDate = new DateTime(1903, 6, 25) },
                new Author { Id = 3, FirstName = "Agatha", LastName = "Christie", Email = "a.christie@email.com", BirthDate = new DateTime(1890, 9, 15) }
            );

            // Seed Genres
            modelBuilder.Entity<Genre>().HasData(
                new Genre { Id = 1, Name = "Fantasy", Description = "Fantasy literature featuring magical elements" },
                new Genre { Id = 2, Name = "Dystopian Fiction", Description = "Fiction depicting a society where life is typically miserable" },
                new Genre { Id = 3, Name = "Mystery", Description = "Fiction dealing with the solution of a crime or the unraveling of secrets" }
            );

            // Seed Books
            modelBuilder.Entity<Book>().HasData(
                new Book { Id = 1, Title = "Harry Potter and the Philosopher's Stone", ISBN = "978-0747532699", PublicationYear = 1997, AuthorId = 1, GenreId = 1 },
                new Book { Id = 2, Title = "1984", ISBN = "978-0451524935", PublicationYear = 1949, AuthorId = 2, GenreId = 2 },
                new Book { Id = 3, Title = "Murder on the Orient Express", ISBN = "978-0062693662", PublicationYear = 1934, AuthorId = 3, GenreId = 3 }
            );
        }
    }
}