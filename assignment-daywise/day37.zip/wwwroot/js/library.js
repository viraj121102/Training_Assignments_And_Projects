// Library Management System - Main JavaScript Functions

// Global configuration
const LibraryConfig = {
    ajaxTimeout: 30000,
    debounceDelay: 300,
    urls: {
        books: '/Books',
        authors: '/Authors',
        genres: '/Genres'
    }
};

// Utility functions
const LibraryUtils = {
    // Show loading spinner
    showLoading: function(elementId) {
        const element = document.getElementById(elementId);
        if (element) {
            element.style.display = 'block';
        }
    },

    // Hide loading spinner
    hideLoading: function(elementId) {
        const element = document.getElementById(elementId);
        if (element) {
            element.style.display = 'none';
        }
    },

    // Show toast notification
    showToast: function(message, type = 'info') {
        // Create toast element if it doesn't exist
        let toastContainer = document.getElementById('toastContainer');
        if (!toastContainer) {
            toastContainer = document.createElement('div');
            toastContainer.id = 'toastContainer';
            toastContainer.className = 'toast-container position-fixed top-0 end-0 p-3';
            toastContainer.style.zIndex = '9999';
            document.body.appendChild(toastContainer);
        }

        const toastId = 'toast_' + Date.now();
        const toastHtml = `
            <div id="${toastId}" class="toast align-items-center text-white bg-${type} border-0" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="d-flex">
                    <div class="toast-body">
                        ${message}
                    </div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
            </div>
        `;

        toastContainer.insertAdjacentHTML('beforeend', toastHtml);

        const toast = new bootstrap.Toast(document.getElementById(toastId));
        toast.show();

        // Remove toast element after it's hidden
        document.getElementById(toastId).addEventListener('hidden.bs.toast', function() {
            this.remove();
        });
    },

    // Format date for display
    formatDate: function(dateString) {
        if (!dateString) return '';
        const date = new Date(dateString);
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
    },

    // Validate form fields
    validateForm: function(formId) {
        const form = document.getElementById(formId);
        if (!form) return false;

        let isValid = true;
        const inputs = form.querySelectorAll('input[required], select[required]');

        inputs.forEach(input => {
            const feedback = input.nextElementSibling;

            if (!input.value.trim()) {
                input.classList.add('is-invalid');
                if (feedback && feedback.classList.contains('invalid-feedback')) {
                    feedback.textContent = 'This field is required.';
                }
                isValid = false;
            } else {
                input.classList.remove('is-invalid');
                input.classList.add('is-valid');
            }
        });

        return isValid;
    },

    // Clear form validation
    clearValidation: function(formId) {
        const form = document.getElementById(formId);
        if (!form) return;

        const inputs = form.querySelectorAll('input, select');
        inputs.forEach(input => {
            input.classList.remove('is-invalid', 'is-valid');
            const feedback = input.nextElementSibling;
            if (feedback && feedback.classList.contains('invalid-feedback')) {
                feedback.textContent = '';
            }
        });
    },

    // Set validation errors from server response
    setValidationErrors: function(errors, formId) {
        if (!errors || !Array.isArray(errors)) return;

        const form = document.getElementById(formId);
        if (!form) return;

        errors.forEach(error => {
            const input = form.querySelector(`[name="${error.field}"], #${error.field}`);
            if (input) {
                input.classList.add('is-invalid');
                const feedback = input.nextElementSibling;
                if (feedback && feedback.classList.contains('invalid-feedback')) {
                    feedback.textContent = error.message;
                }
            }
        });
    },

    // Debounce function for search
    debounce: function(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
};

// AJAX helper functions
const AjaxHelper = {
    // Generic GET request
    get: function(url, successCallback, errorCallback) {
        fetch(url, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                successCallback(data);
            } else {
                if (errorCallback) errorCallback(data);
                LibraryUtils.showToast(data.message || 'An error occurred', 'danger');
            }
        })
        .catch(error => {
            if (errorCallback) errorCallback(error);
            LibraryUtils.showToast('Network error occurred', 'danger');
            console.error('Error:', error);
        });
    },

    // Generic POST request
    post: function(url, data, successCallback, errorCallback) {
        fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify(data)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                successCallback(data);
                LibraryUtils.showToast(data.message || 'Operation completed successfully', 'success');
            } else {
                if (errorCallback) errorCallback(data);
                LibraryUtils.showToast(data.message || 'An error occurred', 'danger');
            }
        })
        .catch(error => {
            if (errorCallback) errorCallback(error);
            LibraryUtils.showToast('Network error occurred', 'danger');
            console.error('Error:', error);
        });
    },

    // Generic PUT request
    put: function(url, data, successCallback, errorCallback) {
        fetch(url, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify(data)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                successCallback(data);
                LibraryUtils.showToast(data.message || 'Updated successfully', 'success');
            } else {
                if (errorCallback) errorCallback(data);
                LibraryUtils.showToast(data.message || 'An error occurred', 'danger');
            }
        })
        .catch(error => {
            if (errorCallback) errorCallback(error);
            LibraryUtils.showToast('Network error occurred', 'danger');
            console.error('Error:', error);
        });
    },

    // Generic DELETE request
    delete: function(url, successCallback, errorCallback) {
        fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                successCallback(data);
                LibraryUtils.showToast(data.message || 'Deleted successfully', 'success');
            } else {
                if (errorCallback) errorCallback(data);
                LibraryUtils.showToast(data.message || 'An error occurred', 'danger');
            }
        })
        .catch(error => {
            if (errorCallback) errorCallback(error);
            LibraryUtils.showToast('Network error occurred', 'danger');
            console.error('Error:', error);
        });
    }
};

// Initialize on document ready
document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});