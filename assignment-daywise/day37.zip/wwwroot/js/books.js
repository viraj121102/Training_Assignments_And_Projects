// Books Management - AJAX Functions

let currentBookId = null;
let authorsCache = [];
let genresCache = [];

// Initialize books page
document.addEventListener('DOMContentLoaded', function() {
    loadAuthorsAndGenres();
    initializeSearch();
});

// Load authors and genres for dropdowns
function loadAuthorsAndGenres() {
    // Load authors
    AjaxHelper.get('/Authors/GetAuthors', function(data) {
        authorsCache = data.data;
        populateAuthorDropdown();
    });

    // Load genres
    AjaxHelper.get('/Genres/GetGenres', function(data) {
        genresCache = data.data;
        populateGenreDropdown();
    });
}

// Populate author dropdown
function populateAuthorDropdown() {
    const authorSelect = document.getElementById('bookAuthorId');
    if (!authorSelect) return;

    authorSelect.innerHTML = '<option value="">Select an author...</option>';
    authorsCache.forEach(author => {
        const option = document.createElement('option');
        option.value = author.id;
        option.textContent = author.fullName;
        authorSelect.appendChild(option);
    });
}

// Populate genre dropdown
function populateGenreDropdown() {
    const genreSelect = document.getElementById('bookGenreId');
    if (!genreSelect) return;

    genreSelect.innerHTML = '<option value="">Select a genre...</option>';
    genresCache.forEach(genre => {
        const option = document.createElement('option');
        option.value = genre.id;
        option.textContent = genre.name;
        genreSelect.appendChild(option);
    });
}

// Initialize search functionality
function initializeSearch() {
    const searchInput = document.getElementById('searchBooks');
    if (searchInput) {
        const debouncedSearch = LibraryUtils.debounce(function(searchTerm) {
            searchBooks(searchTerm);
        }, LibraryConfig.debounceDelay);

        searchInput.addEventListener('input', function() {
            debouncedSearch(this.value.trim());
        });

        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                searchBooks(this.value.trim());
            }
        });
    }
}

// Search books
function searchBooks(searchTerm) {
    LibraryUtils.showLoading('loadingSpinner');

    const url = searchTerm ? 
        `/Books/Search?searchTerm=${encodeURIComponent(searchTerm)}` : 
        '/Books/GetBooks';

    AjaxHelper.get(url, function(data) {
        LibraryUtils.hideLoading('loadingSpinner');
        updateBooksTable(data.data);
    }, function() {
        LibraryUtils.hideLoading('loadingSpinner');
    });
}

// Clear search
function clearSearch() {
    const searchInput = document.getElementById('searchBooks');
    if (searchInput) {
        searchInput.value = '';
        refreshBookList();
    }
}

// Refresh book list
function refreshBookList() {
    LibraryUtils.showLoading('loadingSpinner');

    AjaxHelper.get('/Books/GetBooks', function(data) {
        LibraryUtils.hideLoading('loadingSpinner');
        updateBooksTable(data.data);
    }, function() {
        LibraryUtils.hideLoading('loadingSpinner');
    });
}

// Update books table
function updateBooksTable(books) {
    const tableBody = document.getElementById('booksTableBody');
    const noResultsMessage = document.getElementById('noResultsMessage');

    if (!tableBody) return;

    if (books.length === 0) {
        tableBody.innerHTML = '';
        if (noResultsMessage) noResultsMessage.style.display = 'block';
        return;
    }

    if (noResultsMessage) noResultsMessage.style.display = 'none';

    const html = books.map(book => `
        <tr data-book-id="${book.id}">
            <td><strong>${book.title}</strong></td>
            <td>${book.authorName || ''}</td>
            <td><span class="badge bg-secondary">${book.genreName || ''}</span></td>
            <td>${book.publicationYear}</td>
            <td><code>${book.isbn}</code></td>
            <td>
                <div class="btn-group btn-group-sm" role="group">
                    <a href="/Books/Details/${book.id}" class="btn btn-outline-info" title="View Details">
                        <i class="fas fa-eye"></i>
                    </a>
                    <button type="button" class="btn btn-outline-warning" onclick="editBook(${book.id})" title="Edit">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button type="button" class="btn btn-outline-danger" onclick="deleteBook(${book.id})" title="Delete">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </td>
        </tr>
    `).join('');

    tableBody.innerHTML = html;
}

// Prepare create book modal
function prepareCreateBook() {
    currentBookId = null;

    // Reset form
    document.getElementById('bookForm').reset();
    LibraryUtils.clearValidation('bookForm');

    // Update modal title and button
    document.getElementById('bookModalLabel').textContent = 'Add New Book';
    document.getElementById('saveBookBtn').innerHTML = '<span id="saveBookSpinner" class="spinner-border spinner-border-sm" style="display: none;"></span> Add Book';

    // Clear hidden ID field
    document.getElementById('bookId').value = '';
}

// Edit book
function editBook(bookId) {
    currentBookId = bookId;

    // Update modal title and button
    document.getElementById('bookModalLabel').textContent = 'Edit Book';
    document.getElementById('saveBookBtn').innerHTML = '<span id="saveBookSpinner" class="spinner-border spinner-border-sm" style="display: none;"></span> Update Book';

    // Load book data
    LibraryUtils.showLoading('saveBookSpinner');

    AjaxHelper.get(`/Books/GetBooks`, function(data) {
        const book = data.data.find(b => b.id === bookId);
        if (book) {
            document.getElementById('bookId').value = book.id;
            document.getElementById('bookTitle').value = book.title;
            document.getElementById('bookISBN').value = book.isbn;
            document.getElementById('bookPublicationYear').value = book.publicationYear;

            // Find and select author and genre
            const authorOption = Array.from(document.getElementById('bookAuthorId').options)
                .find(option => option.text === book.authorName);
            if (authorOption) authorOption.selected = true;

            const genreOption = Array.from(document.getElementById('bookGenreId').options)
                .find(option => option.text === book.genreName);
            if (genreOption) genreOption.selected = true;

            // Clear validation
            LibraryUtils.clearValidation('bookForm');

            // Show modal
            const modal = new bootstrap.Modal(document.getElementById('bookModal'));
            modal.show();
        }
        LibraryUtils.hideLoading('saveBookSpinner');
    }, function() {
        LibraryUtils.hideLoading('saveBookSpinner');
    });
}

// Save book (create or update)
function saveBook() {
    // Validate form
    if (!LibraryUtils.validateForm('bookForm')) {
        return;
    }

    const saveBtn = document.getElementById('saveBookBtn');
    const spinner = document.getElementById('saveBookSpinner');

    // Show loading
    saveBtn.disabled = true;
    spinner.style.display = 'inline-block';

    // Prepare data
    const formData = {
        id: currentBookId || 0,
        title: document.getElementById('bookTitle').value.trim(),
        isbn: document.getElementById('bookISBN').value.trim(),
        publicationYear: parseInt(document.getElementById('bookPublicationYear').value),
        authorId: parseInt(document.getElementById('bookAuthorId').value),
        genreId: parseInt(document.getElementById('bookGenreId').value)
    };

    // Determine URL and method
    const url = currentBookId ? '/Books/UpdateAjax' : '/Books/CreateAjax';
    const method = currentBookId ? 'put' : 'post';

    AjaxHelper[method](url, formData, function(data) {
        // Success
        const modal = bootstrap.Modal.getInstance(document.getElementById('bookModal'));
        modal.hide();

        refreshBookList();

        // Reset form
        document.getElementById('bookForm').reset();
        LibraryUtils.clearValidation('bookForm');
        currentBookId = null;

    }, function(data) {
        // Error - handle validation errors
        if (data.errors && Array.isArray(data.errors)) {
            LibraryUtils.setValidationErrors(data.errors, 'bookForm');
        }
    });

    // Always hide loading
    saveBtn.disabled = false;
    spinner.style.display = 'none';
}

// Delete book
function deleteBook(bookId) {
    if (!confirm('Are you sure you want to delete this book?')) {
        return;
    }

    AjaxHelper.delete(`/Books/Delete/${bookId}`, function(data) {
        refreshBookList();
    });
}

// Handle modal events
document.addEventListener('DOMContentLoaded', function() {
    const bookModal = document.getElementById('bookModal');
    if (bookModal) {
        bookModal.addEventListener('hidden.bs.modal', function() {
            document.getElementById('bookForm').reset();
            LibraryUtils.clearValidation('bookForm');
            currentBookId = null;
        });
    }
});