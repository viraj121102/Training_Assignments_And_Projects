// Genres Management - AJAX Functions

let currentGenreId = null;

// Initialize genres page
document.addEventListener('DOMContentLoaded', function() {
    initializeGenreSearch();
});

// Initialize search functionality
function initializeGenreSearch() {
    const searchInput = document.getElementById('searchGenres');
    if (searchInput) {
        const debouncedSearch = LibraryUtils.debounce(function(searchTerm) {
            searchGenres(searchTerm);
        }, LibraryConfig.debounceDelay);

        searchInput.addEventListener('input', function() {
            debouncedSearch(this.value.trim());
        });

        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                searchGenres(this.value.trim());
            }
        });
    }
}

// Search genres
function searchGenres(searchTerm) {
    LibraryUtils.showLoading('genreLoadingSpinner');

    const url = searchTerm ? 
        `/Genres/Search?searchTerm=${encodeURIComponent(searchTerm)}` : 
        '/Genres/GetGenres';

    AjaxHelper.get(url, function(data) {
        LibraryUtils.hideLoading('genreLoadingSpinner');
        updateGenresTable(data.data);
    }, function() {
        LibraryUtils.hideLoading('genreLoadingSpinner');
    });
}

// Clear search
function clearGenreSearch() {
    const searchInput = document.getElementById('searchGenres');
    if (searchInput) {
        searchInput.value = '';
        refreshGenreList();
    }
}

// Refresh genre list
function refreshGenreList() {
    LibraryUtils.showLoading('genreLoadingSpinner');

    AjaxHelper.get('/Genres/GetGenres', function(data) {
        LibraryUtils.hideLoading('genreLoadingSpinner');
        updateGenresTable(data.data);
    }, function() {
        LibraryUtils.hideLoading('genreLoadingSpinner');
    });
}

// Update genres table
function updateGenresTable(genres) {
    const tableBody = document.getElementById('genresTableBody');
    const noResultsMessage = document.getElementById('genreNoResultsMessage');

    if (!tableBody) return;

    if (genres.length === 0) {
        tableBody.innerHTML = '';
        if (noResultsMessage) noResultsMessage.style.display = 'block';
        return;
    }

    if (noResultsMessage) noResultsMessage.style.display = 'none';

    const html = genres.map(genre => `
        <tr data-genre-id="${genre.id}">
            <td><strong>${genre.name}</strong></td>
            <td>${genre.description || ''}</td>
            <td><span class="badge bg-secondary">${genre.bookCount} book(s)</span></td>
            <td>
                <div class="btn-group btn-group-sm" role="group">
                    <a href="/Genres/Details/${genre.id}" class="btn btn-outline-info" title="View Details">
                        <i class="fas fa-eye"></i>
                    </a>
                    <button type="button" class="btn btn-outline-warning" onclick="editGenre(${genre.id})" title="Edit">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button type="button" class="btn btn-outline-danger" onclick="deleteGenre(${genre.id})" title="Delete">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </td>
        </tr>
    `).join('');

    tableBody.innerHTML = html;
}

// Prepare create genre modal
function prepareCreateGenre() {
    currentGenreId = null;

    // Reset form
    document.getElementById('genreForm').reset();
    LibraryUtils.clearValidation('genreForm');

    // Update modal title and button
    document.getElementById('genreModalLabel').textContent = 'Add New Genre';
    document.getElementById('saveGenreBtn').innerHTML = '<span id="saveGenreSpinner" class="spinner-border spinner-border-sm" style="display: none;"></span> Add Genre';

    // Clear hidden ID field
    document.getElementById('genreId').value = '';
}

// Edit genre
function editGenre(genreId) {
    currentGenreId = genreId;

    // Update modal title and button
    document.getElementById('genreModalLabel').textContent = 'Edit Genre';
    document.getElementById('saveGenreBtn').innerHTML = '<span id="saveGenreSpinner" class="spinner-border spinner-border-sm" style="display: none;"></span> Update Genre';

    // Load genre data
    LibraryUtils.showLoading('saveGenreSpinner');

    AjaxHelper.get('/Genres/GetGenres', function(data) {
        const genre = data.data.find(g => g.id === genreId);
        if (genre) {
            document.getElementById('genreId').value = genre.id;
            document.getElementById('genreName').value = genre.name;
            document.getElementById('genreDescription').value = genre.description || '';

            // Clear validation
            LibraryUtils.clearValidation('genreForm');

            // Show modal
            const modal = new bootstrap.Modal(document.getElementById('genreModal'));
            modal.show();
        }
        LibraryUtils.hideLoading('saveGenreSpinner');
    }, function() {
        LibraryUtils.hideLoading('saveGenreSpinner');
    });
}

// Save genre (create or update)
function saveGenre() {
    // Validate form
    if (!LibraryUtils.validateForm('genreForm')) {
        return;
    }

    const saveBtn = document.getElementById('saveGenreBtn');
    const spinner = document.getElementById('saveGenreSpinner');

    // Show loading
    saveBtn.disabled = true;
    spinner.style.display = 'inline-block';

    // Prepare data
    const formData = {
        id: currentGenreId || 0,
        name: document.getElementById('genreName').value.trim(),
        description: document.getElementById('genreDescription').value.trim()
    };

    // Determine URL and method
    const url = currentGenreId ? '/Genres/UpdateAjax' : '/Genres/CreateAjax';
    const method = currentGenreId ? 'put' : 'post';

    AjaxHelper[method](url, formData, function(data) {
        // Success
        const modal = bootstrap.Modal.getInstance(document.getElementById('genreModal'));
        modal.hide();

        refreshGenreList();

        // Reset form
        document.getElementById('genreForm').reset();
        LibraryUtils.clearValidation('genreForm');
        currentGenreId = null;

    }, function(data) {
        // Error - handle validation errors
        if (data.errors && Array.isArray(data.errors)) {
            LibraryUtils.setValidationErrors(data.errors, 'genreForm');
        }
    });

    // Always hide loading
    saveBtn.disabled = false;
    spinner.style.display = 'none';
}

// Delete genre
function deleteGenre(genreId) {
    if (!confirm('Are you sure you want to delete this genre? This action cannot be undone.')) {
        return;
    }

    AjaxHelper.delete(`/Genres/Delete/${genreId}`, function(data) {
        refreshGenreList();
    });
}

// Handle modal events
document.addEventListener('DOMContentLoaded', function() {
    const genreModal = document.getElementById('genreModal');
    if (genreModal) {
        genreModal.addEventListener('hidden.bs.modal', function() {
            document.getElementById('genreForm').reset();
            LibraryUtils.clearValidation('genreForm');
            currentGenreId = null;
        });
    }
});