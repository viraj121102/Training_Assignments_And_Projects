// Authors Management - AJAX Functions

let currentAuthorId = null;

// Initialize authors page
document.addEventListener('DOMContentLoaded', function() {
    initializeAuthorSearch();
});

// Initialize search functionality
function initializeAuthorSearch() {
    const searchInput = document.getElementById('searchAuthors');
    if (searchInput) {
        const debouncedSearch = LibraryUtils.debounce(function(searchTerm) {
            searchAuthors(searchTerm);
        }, LibraryConfig.debounceDelay);

        searchInput.addEventListener('input', function() {
            debouncedSearch(this.value.trim());
        });

        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                searchAuthors(this.value.trim());
            }
        });
    }
}

// Search authors
function searchAuthors(searchTerm) {
    LibraryUtils.showLoading('authorLoadingSpinner');

    const url = searchTerm ? 
        `/Authors/Search?searchTerm=${encodeURIComponent(searchTerm)}` : 
        '/Authors/GetAuthors';

    AjaxHelper.get(url, function(data) {
        LibraryUtils.hideLoading('authorLoadingSpinner');
        updateAuthorsTable(data.data);
    }, function() {
        LibraryUtils.hideLoading('authorLoadingSpinner');
    });
}

// Clear search
function clearAuthorSearch() {
    const searchInput = document.getElementById('searchAuthors');
    if (searchInput) {
        searchInput.value = '';
        refreshAuthorList();
    }
}

// Refresh author list
function refreshAuthorList() {
    LibraryUtils.showLoading('authorLoadingSpinner');

    AjaxHelper.get('/Authors/GetAuthors', function(data) {
        LibraryUtils.hideLoading('authorLoadingSpinner');
        updateAuthorsTable(data.data);
    }, function() {
        LibraryUtils.hideLoading('authorLoadingSpinner');
    });
}

// Update authors table
function updateAuthorsTable(authors) {
    const tableBody = document.getElementById('authorsTableBody');
    const noResultsMessage = document.getElementById('authorNoResultsMessage');

    if (!tableBody) return;

    if (authors.length === 0) {
        tableBody.innerHTML = '';
        if (noResultsMessage) noResultsMessage.style.display = 'block';
        return;
    }

    if (noResultsMessage) noResultsMessage.style.display = 'none';

    const html = authors.map(author => `
        <tr data-author-id="${author.id}">
            <td><strong>${author.fullName}</strong></td>
            <td>${author.email || ''}</td>
            <td>${author.birthDate ? LibraryUtils.formatDate(author.birthDate) : '<span class="text-muted">Not specified</span>'}</td>
            <td><span class="badge bg-info">${author.bookCount} book(s)</span></td>
            <td>
                <div class="btn-group btn-group-sm" role="group">
                    <a href="/Authors/Details/${author.id}" class="btn btn-outline-info" title="View Details">
                        <i class="fas fa-eye"></i>
                    </a>
                    <button type="button" class="btn btn-outline-warning" onclick="editAuthor(${author.id})" title="Edit">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button type="button" class="btn btn-outline-danger" onclick="deleteAuthor(${author.id})" title="Delete">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </td>
        </tr>
    `).join('');

    tableBody.innerHTML = html;
}

// Prepare create author modal
function prepareCreateAuthor() {
    currentAuthorId = null;

    // Reset form
    document.getElementById('authorForm').reset();
    LibraryUtils.clearValidation('authorForm');

    // Update modal title and button
    document.getElementById('authorModalLabel').textContent = 'Add New Author';
    document.getElementById('saveAuthorBtn').innerHTML = '<span id="saveAuthorSpinner" class="spinner-border spinner-border-sm" style="display: none;"></span> Add Author';

    // Clear hidden ID field
    document.getElementById('authorId').value = '';
}

// Edit author
function editAuthor(authorId) {
    currentAuthorId = authorId;

    // Update modal title and button
    document.getElementById('authorModalLabel').textContent = 'Edit Author';
    document.getElementById('saveAuthorBtn').innerHTML = '<span id="saveAuthorSpinner" class="spinner-border spinner-border-sm" style="display: none;"></span> Update Author';

    // Load author data
    LibraryUtils.showLoading('saveAuthorSpinner');

    AjaxHelper.get('/Authors/GetAuthors', function(data) {
        const author = data.data.find(a => a.id === authorId);
        if (author) {
            document.getElementById('authorId').value = author.id;
            document.getElementById('authorFirstName').value = author.firstName;
            document.getElementById('authorLastName').value = author.lastName;
            document.getElementById('authorEmail').value = author.email || '';
            document.getElementById('authorBirthDate').value = author.birthDate || '';

            // Clear validation
            LibraryUtils.clearValidation('authorForm');

            // Show modal
            const modal = new bootstrap.Modal(document.getElementById('authorModal'));
            modal.show();
        }
        LibraryUtils.hideLoading('saveAuthorSpinner');
    }, function() {
        LibraryUtils.hideLoading('saveAuthorSpinner');
    });
}

// Save author (create or update)
function saveAuthor() {
    // Validate form
    if (!LibraryUtils.validateForm('authorForm')) {
        return;
    }

    const saveBtn = document.getElementById('saveAuthorBtn');
    const spinner = document.getElementById('saveAuthorSpinner');

    // Show loading
    saveBtn.disabled = true;
    spinner.style.display = 'inline-block';

    // Prepare data
    const formData = {
        id: currentAuthorId || 0,
        firstName: document.getElementById('authorFirstName').value.trim(),
        lastName: document.getElementById('authorLastName').value.trim(),
        email: document.getElementById('authorEmail').value.trim(),
        birthDate: document.getElementById('authorBirthDate').value || null
    };

    // Determine URL and method
    const url = currentAuthorId ? '/Authors/UpdateAjax' : '/Authors/CreateAjax';
    const method = currentAuthorId ? 'put' : 'post';

    AjaxHelper[method](url, formData, function(data) {
        // Success
        const modal = bootstrap.Modal.getInstance(document.getElementById('authorModal'));
        modal.hide();

        refreshAuthorList();

        // Reset form
        document.getElementById('authorForm').reset();
        LibraryUtils.clearValidation('authorForm');
        currentAuthorId = null;

    }, function(data) {
        // Error - handle validation errors
        if (data.errors && Array.isArray(data.errors)) {
            LibraryUtils.setValidationErrors(data.errors, 'authorForm');
        }
    });

    // Always hide loading
    saveBtn.disabled = false;
    spinner.style.display = 'none';
}

// Delete author
function deleteAuthor(authorId) {
    if (!confirm('Are you sure you want to delete this author? This action cannot be undone.')) {
        return;
    }

    AjaxHelper.delete(`/Authors/Delete/${authorId}`, function(data) {
        refreshAuthorList();
    });
}

// Handle modal events
document.addEventListener('DOMContentLoaded', function() {
    const authorModal = document.getElementById('authorModal');
    if (authorModal) {
        authorModal.addEventListener('hidden.bs.modal', function() {
            document.getElementById('authorForm').reset();
            LibraryUtils.clearValidation('authorForm');
            currentAuthorId = null;
        });
    }
});