# Library Management System

Advanced Library Management System implementing the Repository Design Pattern with Entity Framework Core, CRUD operations, and AJAX integration.

## Assignment Overview

This project fulfills the requirements for Wipro NGA .NET Cohort's advanced coding assignment, demonstrating:

- **Repository Design Pattern** with Entity Framework Core
- **CRUD Operations** for Books, Authors, and Genres
- **AJAX Integration** for asynchronous web interactions
- **Advanced Query Optimization** and error handling
- **Clean Architecture** with separation of concerns

## Features

### 1. Repository Pattern Implementation
- Generic repository interface with CRUD operations
- Entity-specific repositories (Book, Author, Genre)
- Asynchronous operations throughout
- Optimized query performance with EF Core

### 2. Entity Relationships
- **Books**: Many-to-One relationships with Authors and Genres
- **Authors**: One-to-Many relationship with Books
- **Genres**: One-to-Many relationship with Books

### 3. AJAX Functionality
- Real-time search and filtering
- Modal-based create/edit operations
- Asynchronous delete operations
- Client-side validation with server-side integration
- Toast notifications for user feedback

### 4. Advanced Features
- Debounced search functionality
- Data validation and error handling
- Responsive design with Bootstrap 5
- Loading states and user feedback
- Optimized database queries with eager loading

## Technology Stack

- **Backend**: ASP.NET Core 8.0 MVC
- **Database**: Entity Framework Core with SQL Server
- **Frontend**: HTML5, CSS3, JavaScript (ES6), Bootstrap 5
- **AJAX**: Fetch API for asynchronous operations
- **Icons**: Font Awesome 6

## Project Structure

```
LibraryManagementSystem/
├── Controllers/           # MVC Controllers with AJAX endpoints
├── Data/                 # EF Core DbContext
├── Models/               # Entity models
├── Repositories/         # Repository pattern implementation
├── Views/                # Razor views with AJAX integration
├── wwwroot/
│   ├── css/             # Custom stylesheets
│   └── js/              # JavaScript files with AJAX functionality
├── Program.cs           # Application startup and configuration
└── appsettings.json     # Configuration settings
```

## Setup Instructions

1. **Prerequisites**:
   - .NET 8.0 SDK
   - SQL Server (LocalDB recommended for development)
   - Visual Studio 2022 or VS Code

2. **Database Setup**:
   ```bash
   # Run the application - database will be created automatically
   dotnet run
   ```

3. **Run the Application**:
   ```bash
   dotnet restore
   dotnet build
   dotnet run
   ```

4. **Access the Application**:
   - Navigate to `https://localhost:5001` or `http://localhost:5000`

## Database Schema

### Books Table
- Id (Primary Key)
- Title (Required, Max 200 chars)
- ISBN (Required, Unique, Max 20 chars)
- PublicationYear (Range: 1000-3000)
- AuthorId (Foreign Key)
- GenreId (Foreign Key)

### Authors Table
- Id (Primary Key)
- FirstName (Required, Max 100 chars)
- LastName (Required, Max 100 chars)
- Email (Unique, Max 255 chars)
- BirthDate (Optional)

### Genres Table
- Id (Primary Key)
- Name (Required, Unique, Max 100 chars)
- Description (Optional, Max 500 chars)

## Key Implementation Details

### Repository Pattern
- `IGenericRepository<T>` provides common CRUD operations
- Entity-specific repositories extend the generic repository
- Asynchronous operations throughout for better performance
- Proper error handling and logging

### AJAX Integration
- Fetch API for modern, promise-based HTTP requests
- Debounced search to prevent excessive API calls
- Modal-based forms with client-side validation
- Real-time table updates without page refreshes

### Error Handling
- Comprehensive server-side validation
- Client-side validation with Bootstrap feedback
- Toast notifications for user feedback
- Graceful error recovery

## Assignment Requirements Fulfilled

✅ **User Story 1**: Repository Pattern with EF Core
- Generic repository interface with CRUD operations
- Entity-specific repositories extending generic repository
- Effective data access handling

✅ **User Story 2**: Basic CRUD Operations with EF Core
- CRUD operations for Books, Authors, and Genres
- Entity relationships with navigation properties
- Optimized LINQ queries with eager loading
- Asynchronous operations throughout

✅ **User Story 3**: AJAX Integration with MVC
- AJAX calls for fetch and update operations
- AJAX-enabled forms for all entities
- Integration with MVC controllers and repositories
- Comprehensive error handling for AJAX calls

✅ **User Story 4**: Advanced Query Optimization and Error Handling
- Advanced query techniques (filtering, searching, pagination support)
- Comprehensive error handling for both repository and AJAX operations
- Meaningful error messages and graceful recovery

## Usage Guide

### Managing Books
1. Navigate to Books section
2. Use search to filter books by title, author, genre, or ISBN
3. Click "Add New Book" to create via AJAX modal
4. Use action buttons to view details, edit, or delete

### Managing Authors
1. Navigate to Authors section
2. Search authors by name or email
3. View author details including their books
4. Create, edit, or delete authors (with relationship validation)

### Managing Genres
1. Navigate to Genres section
2. Search genres by name or description
3. View genre details and associated books
4. Manage genres with proper relationship handling

## Testing

The application includes comprehensive error handling and validation:
- Client-side form validation
- Server-side business logic validation
- Database constraint validation
- AJAX error handling with user feedback

## Performance Optimizations

- Asynchronous operations throughout
- Debounced search to reduce server load
- Eager loading for related data
- Optimized database queries
- Client-side caching of dropdown data

## Security Considerations

- CSRF protection on all forms
- Input validation and sanitization
- SQL injection prevention through EF Core
- XSS prevention with proper HTML encoding

## Future Enhancements

- Pagination for large datasets
- Advanced filtering and sorting options
- Export functionality (PDF, Excel)
- User authentication and authorization
- Audit logging
- File upload for book covers

## Contributing

This project was created as part of a coding assignment demonstrating advanced .NET development concepts. The implementation showcases best practices in:
- Clean Architecture
- Repository Design Pattern
- Entity Framework Core
- AJAX and modern JavaScript
- Responsive web design

---

**Author**: Created for Wipro NGA .NET Cohort
**Date**: September 2024
**Assignment**: Complex Scenario-Based Coding Assignment - Advanced Library Management System