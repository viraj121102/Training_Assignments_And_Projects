# Secure Web Application - ASP.NET Core JWT Authentication

This is a secure ASP.NET Core web application that implements JWT-based authentication, HTTPS communication, token validation, and role-based access control (RBAC).

## Features

### ✅ User Story 1: JWT Authentication
- JWT-based authentication using ASP.NET Core's JwtBearerAuthentication middleware
- Configured AddJwtBearer() method with proper token validation
- Server validates JWT signature and token integrity
- Returns JWT token upon successful login
- Protected endpoints accessible only with valid JWT token in Authorization header

### ✅ User Story 2: Secure Communication with HTTPS
- SSL/TLS configuration for secure communication
- HttpsRedirection middleware enabled
- All cookies sent with Secure and HttpOnly flags
- HTTP requests rejected and redirected to HTTPS
- Port 443 configured for HTTPS communication

### ✅ User Story 3: Token Expiry and Validation
- JWT tokens include expiry time (exp) in payload
- Server rejects expired tokens
- Token validation includes issuer (iss), subject (sub), and expiry time
- Appropriate error messages for invalid/expired tokens

### ✅ User Story 4: Role-Based Access Control (RBAC)
- Role-based access control using JWT claims
- Support for "Admin" and "User" roles
- Protected routes using [Authorize] attributes with role requirements
- JWT tokens contain user roles as claims

## Project Structure

```
SecureWebApp/
├── Controllers/
│   ├── AuthController.cs       # Authentication endpoints
│   └── UsersController.cs      # Protected user endpoints
├── Models/
│   ├── User.cs                 # User model
│   ├── LoginModel.cs           # Login request model
│   ├── JwtSettings.cs          # JWT configuration model
│   └── ApiResponse.cs          # API response models
├── Services/
│   ├── IJwtTokenService.cs     # JWT service interface
│   ├── JwtTokenService.cs      # JWT token generation/validation
│   ├── IUserService.cs         # User service interface
│   └── UserService.cs          # User authentication service
├── Middleware/
│   └── ErrorHandlingMiddleware.cs  # Global error handling
├── Properties/
│   └── launchSettings.json     # Launch configuration
├── Program.cs                  # Application entry point
├── appsettings.json           # Application configuration
└── SecureWebApp.csproj        # Project file
```

## Setup Instructions

### Prerequisites
- .NET 8.0 SDK or later
- Visual Studio 2022 or VS Code
- HTTPS certificate (for production)

### Installation Steps

1. **Extract and navigate to the project**
   ```bash
   unzip SecureWebApp.zip
   cd SecureWebApp
   ```

2. **Restore NuGet packages**
   ```bash
   dotnet restore
   ```

3. **Build the project**
   ```bash
   dotnet build
   ```

4. **Run the application**
   ```bash
   dotnet run
   ```

5. **Access the application**
   - HTTPS: https://localhost:7089
   - Swagger UI: https://localhost:7089/swagger

## API Endpoints

### Authentication Endpoints
- `POST /api/auth/login` - User login
- `POST /api/auth/validate-token` - Token validation  
- `POST /api/auth/logout` - User logout

### Protected Endpoints (Require JWT Token)
- `GET /api/users/profile` - Get current user profile (All authenticated users)
- `GET /api/users/dashboard` - Get user dashboard (All authenticated users)
- `GET /api/users` - Get all users (Admin only)
- `GET /api/users/{id}` - Get user by ID (Admin only)
- `GET /api/users/admin/dashboard` - Admin dashboard (Admin only)

## Default Users

For testing purposes, the application includes these default users:

| Username | Password | Role  | Email |
|----------|----------|-------|-------|
| admin    | admin123 | Admin | admin@securewebapp.com |
| user1    | user123  | User  | user1@securewebapp.com |
| user2    | user456  | User  | user2@securewebapp.com |

## Usage Examples

### 1. Login Request
```bash
POST /api/auth/login
Content-Type: application/json

{
  "username": "admin",
  "password": "admin123"
}
```

### 2. Access Protected Endpoint
```bash
GET /api/users/profile
Authorization: Bearer <your-jwt-token>
```

### 3. Admin-Only Endpoint
```bash
GET /api/users
Authorization: Bearer <admin-jwt-token>
```

## Security Features

### JWT Configuration
- **Secret Key**: 256-bit secure key for token signing
- **Issuer/Audience Validation**: Prevents token misuse
- **Expiry Time**: 60 minutes (configurable)
- **Clock Skew**: Zero tolerance for expired tokens

### HTTPS Configuration
- **Forced HTTPS**: All HTTP requests redirected to HTTPS
- **Secure Cookies**: HttpOnly and Secure flags set
- **HSTS**: HTTP Strict Transport Security enabled in production

### Password Security
- **Hash Function**: SHA256 with salt (demo - use BCrypt in production)
- **No Plain Text**: Passwords never stored or transmitted in plain text

### Error Handling
- **Global Exception Handler**: Centralized error processing
- **Security Headers**: Appropriate HTTP status codes
- **Logging**: Security events logged for monitoring

## Configuration

### JWT Settings (appsettings.json)
```json
{
  "JwtSettings": {
    "SecretKey": "Your-256-bit-secret-key",
    "Issuer": "SecureWebApp",
    "Audience": "SecureWebAppUsers", 
    "ExpiryInMinutes": 60
  }
}
```

## Production Deployment

### Security Considerations
1. **Replace default JWT secret** with a strong, unique key
2. **Use proper SSL certificates** from a trusted CA
3. **Enable HSTS** and security headers
4. **Implement proper logging** and monitoring
5. **Use a real database** instead of in-memory storage
6. **Implement password policies** and account lockout
7. **Add input validation** and sanitization
8. **Configure CORS** properly for your domain

### Database Integration
Replace the in-memory `UserService` with Entity Framework Core:
```csharp
// Add to Program.cs
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(connectionString));
```

## Testing

### Test Authentication Flow
1. Start the application
2. Navigate to Swagger UI (https://localhost:7089/swagger)
3. Use the `/api/auth/login` endpoint with default credentials
4. Copy the returned JWT token
5. Click "Authorize" in Swagger and enter: `Bearer <your-token>`
6. Test protected endpoints

### Test Role-Based Access
1. Login as `admin` user - should access all endpoints
2. Login as `user1` - should be denied access to admin endpoints
3. Try accessing endpoints without token - should get 401 Unauthorized

## Troubleshooting

### Common Issues
1. **HTTPS Certificate Errors**: Trust the development certificate with `dotnet dev-certs https --trust`
2. **Port Already in Use**: Change ports in `launchSettings.json`
3. **JWT Validation Errors**: Verify the secret key matches in configuration
4. **Unauthorized Access**: Ensure JWT token is included in Authorization header

## License
This project is for educational purposes as part of an ASP.NET Core security assignment.
