using Microsoft.AspNetCore.Mvc;
using SecureWebApp.Models;
using SecureWebApp.Services;
using System.ComponentModel.DataAnnotations;

namespace SecureWebApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly IJwtTokenService _jwtTokenService;
        private readonly IUserService _userService;
        private readonly ILogger<AuthController> _logger;

        public AuthController(
            IJwtTokenService jwtTokenService,
            IUserService userService,
            ILogger<AuthController> logger)
        {
            _jwtTokenService = jwtTokenService;
            _userService = userService;
            _logger = logger;
        }

        /// <summary>
        /// Authenticates user and returns JWT token
        /// </summary>
        /// <param name="loginModel">Login credentials</param>
        /// <returns>JWT token and user information</returns>
        [HttpPost("login")]
        public async Task<ActionResult<ApiResponse<AuthResponse>>> Login([FromBody] LoginModel loginModel)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(new ApiResponse<AuthResponse>
                    {
                        Success = false,
                        Message = "Invalid login data provided.",
                        Data = null
                    });
                }

                var user = await _userService.AuthenticateAsync(loginModel.Username, loginModel.Password);

                if (user == null)
                {
                    _logger.LogWarning("Failed login attempt for username: {Username}", loginModel.Username);

                    return Unauthorized(new ApiResponse<AuthResponse>
                    {
                        Success = false,
                        Message = "Invalid username or password.",
                        Data = null
                    });
                }

                var token = _jwtTokenService.GenerateToken(user);
                var expires = DateTime.UtcNow.AddMinutes(60); // Should match JWT expiry

                _logger.LogInformation("User {Username} successfully authenticated", user.Username);

                var authResponse = new AuthResponse
                {
                    Token = token,
                    Expires = expires,
                    Username = user.Username,
                    Role = user.Role
                };

                // Set secure cookie with token (optional)
                Response.Cookies.Append("auth-token", token, new CookieOptions
                {
                    HttpOnly = true,
                    Secure = true,
                    SameSite = SameSiteMode.Strict,
                    Expires = expires
                });

                return Ok(new ApiResponse<AuthResponse>
                {
                    Success = true,
                    Message = "Login successful.",
                    Data = authResponse
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during login process");
                return StatusCode(500, new ApiResponse<AuthResponse>
                {
                    Success = false,
                    Message = "An error occurred during login.",
                    Data = null
                });
            }
        }

        /// <summary>
        /// Validates JWT token
        /// </summary>
        /// <param name="token">JWT token to validate</param>
        /// <returns>Token validation result</returns>
        [HttpPost("validate-token")]
        public ActionResult<ApiResponse<object>> ValidateToken([FromBody, Required] string token)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(token))
                {
                    return BadRequest(new ApiResponse<object>
                    {
                        Success = false,
                        Message = "Token is required.",
                        Data = null
                    });
                }

                if (_jwtTokenService.IsTokenExpired(token))
                {
                    return Unauthorized(new ApiResponse<object>
                    {
                        Success = false,
                        Message = "Token has expired.",
                        Data = null
                    });
                }

                var principal = _jwtTokenService.ValidateToken(token);

                if (principal == null)
                {
                    return Unauthorized(new ApiResponse<object>
                    {
                        Success = false,
                        Message = "Invalid token.",
                        Data = null
                    });
                }

                return Ok(new ApiResponse<object>
                {
                    Success = true,
                    Message = "Token is valid.",
                    Data = new { 
                        Username = principal.Identity?.Name,
                        Role = principal.FindFirst(System.Security.Claims.ClaimTypes.Role)?.Value
                    }
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during token validation");
                return StatusCode(500, new ApiResponse<object>
                {
                    Success = false,
                    Message = "An error occurred during token validation.",
                    Data = null
                });
            }
        }

        /// <summary>
        /// Logs out user by clearing cookies
        /// </summary>
        /// <returns>Logout confirmation</returns>
        [HttpPost("logout")]
        public ActionResult<ApiResponse<object>> Logout()
        {
            Response.Cookies.Delete("auth-token");

            return Ok(new ApiResponse<object>
            {
                Success = true,
                Message = "Logout successful.",
                Data = null
            });
        }
    }
}