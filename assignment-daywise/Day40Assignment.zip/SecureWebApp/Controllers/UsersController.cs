using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SecureWebApp.Models;
using SecureWebApp.Services;
using System.Security.Claims;

namespace SecureWebApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize] // All endpoints in this controller require authentication
    public class UsersController : ControllerBase
    {
        private readonly IUserService _userService;
        private readonly ILogger<UsersController> _logger;

        public UsersController(IUserService userService, ILogger<UsersController> logger)
        {
            _userService = userService;
            _logger = logger;
        }

        /// <summary>
        /// Gets current user profile - Available to all authenticated users
        /// </summary>
        /// <returns>Current user information</returns>
        [HttpGet("profile")]
        public async Task<ActionResult<ApiResponse<User>>> GetProfile()
        {
            try
            {
                var username = User.Identity?.Name;

                if (string.IsNullOrEmpty(username))
                {
                    return Unauthorized(new ApiResponse<User>
                    {
                        Success = false,
                        Message = "User not authenticated.",
                        Data = null
                    });
                }

                var user = await _userService.GetUserByUsernameAsync(username);

                if (user == null)
                {
                    return NotFound(new ApiResponse<User>
                    {
                        Success = false,
                        Message = "User not found.",
                        Data = null
                    });
                }

                // Don't return password
                user.Password = string.Empty;

                return Ok(new ApiResponse<User>
                {
                    Success = true,
                    Message = "Profile retrieved successfully.",
                    Data = user
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving user profile");
                return StatusCode(500, new ApiResponse<User>
                {
                    Success = false,
                    Message = "An error occurred while retrieving profile.",
                    Data = null
                });
            }
        }

        /// <summary>
        /// Gets all users - Admin only endpoint
        /// </summary>
        /// <returns>List of all users</returns>
        [HttpGet]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult<ApiResponse<IEnumerable<User>>>> GetAllUsers()
        {
            try
            {
                var users = await _userService.GetAllUsersAsync();

                return Ok(new ApiResponse<IEnumerable<User>>
                {
                    Success = true,
                    Message = "Users retrieved successfully.",
                    Data = users
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving all users");
                return StatusCode(500, new ApiResponse<IEnumerable<User>>
                {
                    Success = false,
                    Message = "An error occurred while retrieving users.",
                    Data = null
                });
            }
        }

        /// <summary>
        /// Gets user by ID - Admin only endpoint
        /// </summary>
        /// <param name="id">User ID</param>
        /// <returns>User information</returns>
        [HttpGet("{id:int}")]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult<ApiResponse<User>>> GetUserById(int id)
        {
            try
            {
                if (id <= 0)
                {
                    return BadRequest(new ApiResponse<User>
                    {
                        Success = false,
                        Message = "Invalid user ID.",
                        Data = null
                    });
                }

                var user = await _userService.GetUserByIdAsync(id);

                if (user == null)
                {
                    return NotFound(new ApiResponse<User>
                    {
                        Success = false,
                        Message = $"User with ID {id} not found.",
                        Data = null
                    });
                }

                // Don't return password
                user.Password = string.Empty;

                return Ok(new ApiResponse<User>
                {
                    Success = true,
                    Message = "User retrieved successfully.",
                    Data = user
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving user with ID {UserId}", id);
                return StatusCode(500, new ApiResponse<User>
                {
                    Success = false,
                    Message = "An error occurred while retrieving user.",
                    Data = null
                });
            }
        }

        /// <summary>
        /// Admin dashboard - Admin only endpoint
        /// </summary>
        /// <returns>Dashboard data</returns>
        [HttpGet("admin/dashboard")]
        [Authorize(Roles = "Admin")]
        public async Task<ActionResult<ApiResponse<object>>> GetAdminDashboard()
        {
            try
            {
                var users = await _userService.GetAllUsersAsync();
                var userStats = new
                {
                    TotalUsers = users.Count(),
                    ActiveUsers = users.Count(u => u.IsActive),
                    AdminUsers = users.Count(u => u.Role == "Admin"),
                    RegularUsers = users.Count(u => u.Role == "User"),
                    RecentUsers = users.OrderByDescending(u => u.CreatedAt).Take(5)
                        .Select(u => new { u.Id, u.Username, u.Email, u.Role, u.CreatedAt })
                };

                return Ok(new ApiResponse<object>
                {
                    Success = true,
                    Message = "Dashboard data retrieved successfully.",
                    Data = userStats
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving admin dashboard data");
                return StatusCode(500, new ApiResponse<object>
                {
                    Success = false,
                    Message = "An error occurred while retrieving dashboard data.",
                    Data = null
                });
            }
        }

        /// <summary>
        /// User dashboard - Available to all authenticated users
        /// </summary>
        /// <returns>User-specific dashboard data</returns>
        [HttpGet("dashboard")]
        public async Task<ActionResult<ApiResponse<object>>> GetUserDashboard()
        {
            try
            {
                var username = User.Identity?.Name;
                var role = User.FindFirst(ClaimTypes.Role)?.Value;

                if (string.IsNullOrEmpty(username))
                {
                    return Unauthorized(new ApiResponse<object>
                    {
                        Success = false,
                        Message = "User not authenticated.",
                        Data = null
                    });
                }

                var user = await _userService.GetUserByUsernameAsync(username);

                if (user == null)
                {
                    return NotFound(new ApiResponse<object>
                    {
                        Success = false,
                        Message = "User not found.",
                        Data = null
                    });
                }

                var dashboardData = new
                {
                    Welcome = $"Welcome back, {user.Username}!",
                    Role = user.Role,
                    LastLogin = DateTime.UtcNow,
                    Profile = new { user.Id, user.Username, user.Email, user.Role, user.CreatedAt },
                    Permissions = role == "Admin" ? 
                        new[] { "View All Users", "Access Admin Dashboard", "Manage Users" } :
                        new[] { "View Profile", "Access User Dashboard" }
                };

                return Ok(new ApiResponse<object>
                {
                    Success = true,
                    Message = "Dashboard data retrieved successfully.",
                    Data = dashboardData
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving user dashboard data");
                return StatusCode(500, new ApiResponse<object>
                {
                    Success = false,
                    Message = "An error occurred while retrieving dashboard data.",
                    Data = null
                });
            }
        }
    }
}