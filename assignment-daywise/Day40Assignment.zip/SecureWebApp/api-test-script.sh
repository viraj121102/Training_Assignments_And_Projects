# API Testing Script for SecureWebApp
# Use this script with tools like curl or Postman to test the application

# 1. Test Login (Admin)
curl -X POST "https://localhost:7089/api/auth/login" -H "Content-Type: application/json" -d '{
  "username": "admin",
  "password": "admin123"
}'

# 2. Test Login (Regular User)
curl -X POST "https://localhost:7089/api/auth/login" -H "Content-Type: application/json" -d '{
  "username": "user1", 
  "password": "user123"
}'

# 3. Test Protected Endpoint (Replace TOKEN_HERE with actual JWT token)
curl -X GET "https://localhost:7089/api/users/profile" -H "Authorization: Bearer TOKEN_HERE"

# 4. Test Admin-Only Endpoint (Replace ADMIN_TOKEN_HERE with admin JWT token)
curl -X GET "https://localhost:7089/api/users" -H "Authorization: Bearer ADMIN_TOKEN_HERE"

# 5. Test Token Validation
curl -X POST "https://localhost:7089/api/auth/validate-token" -H "Content-Type: application/json" -d '"TOKEN_HERE"'

# 6. Test User Dashboard
curl -X GET "https://localhost:7089/api/users/dashboard" -H "Authorization: Bearer TOKEN_HERE"

# 7. Test Admin Dashboard (Admin only)
curl -X GET "https://localhost:7089/api/users/admin/dashboard" -H "Authorization: Bearer ADMIN_TOKEN_HERE"

# 8. Test Logout
curl -X POST "https://localhost:7089/api/auth/logout"

# Test without HTTPS (should redirect)
curl -X GET "http://localhost:5089/api/users/profile" -L

# Test without Authorization header (should return 401)
curl -X GET "https://localhost:7089/api/users/profile"
