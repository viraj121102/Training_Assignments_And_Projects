using SecureWebApp.Models;
using System.Security.Claims;

namespace SecureWebApp.Services
{
    public interface IJwtTokenService
    {
        string GenerateToken(User user);
        ClaimsPrincipal ValidateToken(string token);
        bool IsTokenExpired(string token);
    }
}