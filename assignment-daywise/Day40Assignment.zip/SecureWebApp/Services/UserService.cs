using SecureWebApp.Models;
using System.Security.Cryptography;
using System.Text;

namespace SecureWebApp.Services
{
    public class UserService : IUserService
    {
        // In-memory user store for demonstration
        // In production, this would be replaced with a database
        private readonly List<User> _users;

        public UserService()
        {
            _users = new List<User>
            {
                new User 
                { 
                    Id = 1, 
                    Username = "admin", 
                    Password = HashPassword("admin123"), 
                    Role = "Admin", 
                    Email = "admin@securewebapp.com" 
                },
                new User 
                { 
                    Id = 2, 
                    Username = "user1", 
                    Password = HashPassword("user123"), 
                    Role = "User", 
                    Email = "user1@securewebapp.com" 
                },
                new User 
                { 
                    Id = 3, 
                    Username = "user2", 
                    Password = HashPassword("user456"), 
                    Role = "User", 
                    Email = "user2@securewebapp.com" 
                }
            };
        }

        public async Task<User?> AuthenticateAsync(string username, string password)
        {
            await Task.Delay(1); // Simulate async operation

            var user = _users.FirstOrDefault(x => 
                x.Username.Equals(username, StringComparison.OrdinalIgnoreCase) && 
                x.IsActive);

            if (user != null && VerifyPassword(password, user.Password))
            {
                return user;
            }

            return null;
        }

        public async Task<User?> GetUserByIdAsync(int id)
        {
            await Task.Delay(1); // Simulate async operation
            return _users.FirstOrDefault(x => x.Id == id && x.IsActive);
        }

        public async Task<User?> GetUserByUsernameAsync(string username)
        {
            await Task.Delay(1); // Simulate async operation
            return _users.FirstOrDefault(x => 
                x.Username.Equals(username, StringComparison.OrdinalIgnoreCase) && 
                x.IsActive);
        }

        public async Task<IEnumerable<User>> GetAllUsersAsync()
        {
            await Task.Delay(1); // Simulate async operation
            return _users.Where(x => x.IsActive).Select(u => new User
            {
                Id = u.Id,
                Username = u.Username,
                Role = u.Role,
                Email = u.Email,
                CreatedAt = u.CreatedAt,
                IsActive = u.IsActive
                // Don't return password
            });
        }

        public async Task<bool> UserExistsAsync(string username)
        {
            await Task.Delay(1); // Simulate async operation
            return _users.Any(x => 
                x.Username.Equals(username, StringComparison.OrdinalIgnoreCase) && 
                x.IsActive);
        }

        private static string HashPassword(string password)
        {
            // Simple hash for demonstration - in production use BCrypt or similar
            using var sha256 = SHA256.Create();
            var hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password + "SALT_SecureWebApp"));
            return Convert.ToBase64String(hashedBytes);
        }

        private static bool VerifyPassword(string password, string hashedPassword)
        {
            return HashPassword(password) == hashedPassword;
        }
    }
}