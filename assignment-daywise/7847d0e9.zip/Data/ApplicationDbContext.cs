using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using SecureShoppingApp.Models;

namespace SecureShoppingApp.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Product> Products { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderItem> OrderItems { get; set; }
        public DbSet<ProductReview> ProductReviews { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            // Configure relationships
            builder.Entity<Order>()
                .HasOne(o => o.User)
                .WithMany(u => u.Orders)
                .HasForeignKey(o => o.UserId)
                .OnDelete(DeleteBehavior.Restrict);

            builder.Entity<OrderItem>()
                .HasOne(oi => oi.Order)
                .WithMany(o => o.OrderItems)
                .HasForeignKey(oi => oi.OrderId)
                .OnDelete(DeleteBehavior.Cascade);

            builder.Entity<OrderItem>()
                .HasOne(oi => oi.Product)
                .WithMany(p => p.OrderItems)
                .HasForeignKey(oi => oi.ProductId)
                .OnDelete(DeleteBehavior.Restrict);

            builder.Entity<ProductReview>()
                .HasOne(pr => pr.Product)
                .WithMany(p => p.Reviews)
                .HasForeignKey(pr => pr.ProductId)
                .OnDelete(DeleteBehavior.Cascade);

            builder.Entity<ProductReview>()
                .HasOne(pr => pr.User)
                .WithMany(u => u.Reviews)
                .HasForeignKey(pr => pr.UserId)
                .OnDelete(DeleteBehavior.Restrict);

            // Indexes for performance and security
            builder.Entity<ApplicationUser>()
                .HasIndex(u => u.Email)
                .IsUnique();

            builder.Entity<Product>()
                .HasIndex(p => p.Name);

            builder.Entity<Order>()
                .HasIndex(o => o.UserId);

            // Seed initial data
            SeedData(builder);
        }

        private static void SeedData(ModelBuilder builder)
        {
            // Seed sample products
            builder.Entity<Product>().HasData(
                new Product
                {
                    Id = 1,
                    Name = "Secure Laptop",
                    Description = "High-performance laptop with enhanced security features",
                    Price = 999.99m,
                    StockQuantity = 50,
                    Category = "Electronics",
                    ImageUrl = "/images/laptop.jpg",
                    IsActive = true
                },
                new Product
                {
                    Id = 2,
                    Name = "Security Handbook",
                    Description = "Comprehensive guide to cybersecurity best practices",
                    Price = 29.99m,
                    StockQuantity = 100,
                    Category = "Books",
                    ImageUrl = "/images/book.jpg",
                    IsActive = true
                },
                new Product
                {
                    Id = 3,
                    Name = "Encrypted Storage Device",
                    Description = "Hardware-encrypted external storage for sensitive data",
                    Price = 149.99m,
                    StockQuantity = 25,
                    Category = "Electronics",
                    ImageUrl = "/images/storage.jpg",
                    IsActive = true
                }
            );
        }
    }
}