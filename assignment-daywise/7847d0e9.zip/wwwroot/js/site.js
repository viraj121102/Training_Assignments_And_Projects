// Secure Shopping App JavaScript
$(document).ready(function() {
    // Initialize tooltips
    $('[data-bs-toggle="tooltip"]').tooltip();

    // Auto-hide alerts after 5 seconds
    setTimeout(function() {
        $('.alert').alert('close');
    }, 5000);

    // Password strength indicator
    $('#Password').on('input', function() {
        checkPasswordStrength($(this).val());
    });
});

function checkPasswordStrength(password) {
    let strength = 0;
    let feedback = [];

    if (password.length >= 8) strength++;
    else feedback.push('At least 8 characters');

    if (/[A-Z]/.test(password)) strength++;
    else feedback.push('One uppercase letter');

    if (/[a-z]/.test(password)) strength++;
    else feedback.push('One lowercase letter');

    if (/[0-9]/.test(password)) strength++;
    else feedback.push('One number');

    if (/[^A-Za-z0-9]/.test(password)) strength++;
    else feedback.push('One special character');

    // Update UI based on strength
    const indicator = $('#password-strength');
    if (indicator.length > 0) {
        let strengthText = '';
        let strengthClass = '';

        switch(strength) {
            case 0-1: strengthText = 'Very Weak'; strengthClass = 'text-danger'; break;
            case 2: strengthText = 'Weak'; strengthClass = 'text-warning'; break;
            case 3: strengthText = 'Fair'; strengthClass = 'text-info'; break;
            case 4: strengthText = 'Good'; strengthClass = 'text-primary'; break;
            case 5: strengthText = 'Strong'; strengthClass = 'text-success'; break;
        }

        indicator.html(`<small class="${strengthClass}">Password Strength: ${strengthText}</small>`);
    }
}