using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using SecureShoppingApp.Models;
using SecureShoppingApp.Services;
using Microsoft.AspNetCore.Html;
using System.Text.Encodings.Web;

namespace SecureShoppingApp.Controllers
{
    [AllowAnonymous]
    public class AccountController : Controller
    {
        private readonly IAuthService _authService;
        private readonly ILogger<AccountController> _logger;
        private readonly HtmlEncoder _htmlEncoder;

        public AccountController(IAuthService authService, ILogger<AccountController> logger, HtmlEncoder htmlEncoder)
        {
            _authService = authService;
            _logger = logger;
            _htmlEncoder = htmlEncoder;
        }

        [HttpGet]
        public IActionResult Register(string? returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterViewModel model, string? returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            // Additional server-side validation
            if (!IsValidEmail(model.Email))
            {
                ModelState.AddModelError("Email", "Please provide a valid email address");
                return View(model);
            }

            if (!IsStrongPassword(model.Password))
            {
                ModelState.AddModelError("Password", "Password does not meet security requirements");
                return View(model);
            }

            // Sanitize inputs
            model.FirstName = _htmlEncoder.Encode(model.FirstName.Trim());
            model.LastName = _htmlEncoder.Encode(model.LastName.Trim());
            model.Address = _htmlEncoder.Encode(model.Address.Trim());

            try
            {
                var result = await _authService.RegisterUserAsync(model);

                if (result.Succeeded)
                {
                    _logger.LogInformation("User {Email} registered successfully", model.Email);
                    TempData["SuccessMessage"] = "Registration successful! Please log in.";
                    return RedirectToAction("Login", new { returnUrl });
                }

                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError(string.Empty, error.Description);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Registration error for {Email}", model.Email);
                ModelState.AddModelError(string.Empty, "Registration failed. Please try again.");
            }

            return View(model);
        }

        [HttpGet]
        public IActionResult Login(string? returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model, string? returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            // Rate limiting check (simplified)
            var clientIP = HttpContext.Connection.RemoteIpAddress?.ToString() ?? "unknown";
            if (await IsRateLimitedAsync(clientIP))
            {
                ModelState.AddModelError(string.Empty, "Too many login attempts. Please try again later.");
                return View(model);
            }

            try
            {
                var result = await _authService.LoginUserAsync(model);

                if (result.Succeeded)
                {
                    _logger.LogInformation("User {Email} logged in successfully", model.Email);

                    if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
                    {
                        return Redirect(returnUrl);
                    }

                    return RedirectToAction("Index", "Home");
                }

                if (result.IsLockedOut)
                {
                    _logger.LogWarning("User {Email} account locked out", model.Email);
                    ModelState.AddModelError(string.Empty, "Account locked due to multiple failed attempts.");
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Invalid login attempt.");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Login error for {Email}", model.Email);
                ModelState.AddModelError(string.Empty, "Login failed. Please try again.");
            }

            return View(model);
        }

        [HttpPost]
        [Authorize]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Logout()
        {
            await _authService.LogoutUserAsync();
            _logger.LogInformation("User logged out");

            // Clear any additional cookies or session data
            HttpContext.Session.Clear();

            return RedirectToAction("Index", "Home");
        }

        [HttpGet]
        public IActionResult AccessDenied()
        {
            return View();
        }

        private static bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }

        private static bool IsStrongPassword(string password)
        {
            if (password.Length < 8) return false;
            if (!password.Any(char.IsUpper)) return false;
            if (!password.Any(char.IsLower)) return false;
            if (!password.Any(char.IsDigit)) return false;
            if (!password.Any(ch => "!@#$%^&*()_+-=[]{}|;:,.<>?".Contains(ch))) return false;
            return true;
        }

        private async Task<bool> IsRateLimitedAsync(string clientIP)
        {
            // Simplified rate limiting - in production, use Redis or memory cache
            // This is a basic implementation
            var cacheKey = $"login_attempts_{clientIP}";
            var attempts = HttpContext.Session.GetInt32(cacheKey) ?? 0;

            if (attempts >= 5)
            {
                return true;
            }

            HttpContext.Session.SetInt32(cacheKey, attempts + 1);
            return false;
        }
    }
}