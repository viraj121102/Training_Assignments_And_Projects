using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using SecureShoppingApp.Data;
using SecureShoppingApp.Models;
using System.Text.Encodings.Web;

namespace SecureShoppingApp.Controllers
{
    [Authorize(Roles = "Admin")]
    public class AdminController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<AdminController> _logger;
        private readonly HtmlEncoder _htmlEncoder;

        public AdminController(ApplicationDbContext context, ILogger<AdminController> logger, HtmlEncoder htmlEncoder)
        {
            _context = context;
            _logger = logger;
            _htmlEncoder = htmlEncoder;
        }

        [HttpGet]
        public async Task<IActionResult> Dashboard()
        {
            try
            {
                var model = new AdminDashboardViewModel
                {
                    TotalUsers = await _context.Users.CountAsync(),
                    TotalProducts = await _context.Products.CountAsync(),
                    TotalOrders = await _context.Orders.CountAsync(),
                    TotalRevenue = await _context.Orders
                        .Where(o => o.Status == "Completed")
                        .SumAsync(o => o.TotalAmount),
                    RecentOrders = await _context.Orders
                        .Include(o => o.User)
                        .OrderByDescending(o => o.OrderDate)
                        .Take(10)
                        .Select(o => new OrderSummaryViewModel
                        {
                            Id = o.Id,
                            UserEmail = o.User.Email ?? "Unknown",
                            TotalAmount = o.TotalAmount,
                            OrderDate = o.OrderDate,
                            Status = o.Status
                        })
                        .ToListAsync(),
                    PendingReviews = await _context.ProductReviews
                        .Where(r => !r.IsApproved)
                        .CountAsync()
                };

                return View(model);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading admin dashboard");
                TempData["ErrorMessage"] = "Error loading dashboard data.";
                return View(new AdminDashboardViewModel());
            }
        }

        [HttpGet]
        public async Task<IActionResult> Products()
        {
            try
            {
                var products = await _context.Products
                    .OrderBy(p => p.Name)
                    .ToListAsync();

                return View(products);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading products");
                TempData["ErrorMessage"] = "Error loading products.";
                return View(new List<Product>());
            }
        }

        [HttpGet]
        public IActionResult CreateProduct()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateProduct(Product model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            try
            {
                // Sanitize inputs to prevent XSS
                model.Name = _htmlEncoder.Encode(model.Name.Trim());
                model.Description = _htmlEncoder.Encode(model.Description.Trim());
                model.Category = _htmlEncoder.Encode(model.Category.Trim());

                // Additional validation
                if (await _context.Products.AnyAsync(p => p.Name == model.Name))
                {
                    ModelState.AddModelError("Name", "A product with this name already exists.");
                    return View(model);
                }

                _context.Products.Add(model);
                await _context.SaveChangesAsync();

                _logger.LogInformation("Product {ProductName} created by admin", model.Name);
                TempData["SuccessMessage"] = "Product created successfully!";
                return RedirectToAction(nameof(Products));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating product {ProductName}", model.Name);
                ModelState.AddModelError(string.Empty, "Error creating product. Please try again.");
                return View(model);
            }
        }

        [HttpGet]
        public async Task<IActionResult> Users()
        {
            try
            {
                var users = await _context.Users
                    .Select(u => new UserSummaryViewModel
                    {
                        Id = u.Id,
                        FirstName = u.FirstName,
                        LastName = u.LastName,
                        Email = u.Email ?? string.Empty,
                        RegistrationDate = u.RegistrationDate,
                        IsActive = u.IsActive,
                        OrderCount = u.Orders.Count()
                    })
                    .OrderBy(u => u.LastName)
                    .ToListAsync();

                return View(users);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading users");
                TempData["ErrorMessage"] = "Error loading users.";
                return View(new List<UserSummaryViewModel>());
            }
        }

        [HttpGet]
        public async Task<IActionResult> Reviews()
        {
            try
            {
                var reviews = await _context.ProductReviews
                    .Include(r => r.Product)
                    .Include(r => r.User)
                    .OrderByDescending(r => r.ReviewDate)
                    .Select(r => new ReviewSummaryViewModel
                    {
                        Id = r.Id,
                        ProductName = r.Product.Name,
                        UserName = $"{r.User.FirstName} {r.User.LastName}",
                        Rating = r.Rating,
                        Comment = r.Comment,
                        ReviewDate = r.ReviewDate,
                        IsApproved = r.IsApproved
                    })
                    .ToListAsync();

                return View(reviews);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading reviews");
                TempData["ErrorMessage"] = "Error loading reviews.";
                return View(new List<ReviewSummaryViewModel>());
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ApproveReview(int id)
        {
            try
            {
                var review = await _context.ProductReviews.FindAsync(id);
                if (review != null)
                {
                    review.IsApproved = true;
                    await _context.SaveChangesAsync();
                    _logger.LogInformation("Review {ReviewId} approved", id);
                }

                return RedirectToAction(nameof(Reviews));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error approving review {ReviewId}", id);
                TempData["ErrorMessage"] = "Error approving review.";
                return RedirectToAction(nameof(Reviews));
            }
        }
    }

    // Admin ViewModels
    public class AdminDashboardViewModel
    {
        public int TotalUsers { get; set; }
        public int TotalProducts { get; set; }
        public int TotalOrders { get; set; }
        public decimal TotalRevenue { get; set; }
        public int PendingReviews { get; set; }
        public List<OrderSummaryViewModel> RecentOrders { get; set; } = new();
    }

    public class OrderSummaryViewModel
    {
        public int Id { get; set; }
        public string UserEmail { get; set; } = string.Empty;
        public decimal TotalAmount { get; set; }
        public DateTime OrderDate { get; set; }
        public string Status { get; set; } = string.Empty;
    }

    public class UserSummaryViewModel
    {
        public string Id { get; set; } = string.Empty;
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public DateTime RegistrationDate { get; set; }
        public bool IsActive { get; set; }
        public int OrderCount { get; set; }
    }

    public class ReviewSummaryViewModel
    {
        public int Id { get; set; }
        public string ProductName { get; set; } = string.Empty;
        public string UserName { get; set; } = string.Empty;
        public int Rating { get; set; }
        public string Comment { get; set; } = string.Empty;
        public DateTime ReviewDate { get; set; }
        public bool IsApproved { get; set; }
    }
}