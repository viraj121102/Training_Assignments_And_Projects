using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using SecureShoppingApp.Data;
using SecureShoppingApp.Models;
using System.Security.Claims;
using System.Text.Encodings.Web;

namespace SecureShoppingApp.Controllers
{
    public class ProductsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<ProductsController> _logger;
        private readonly HtmlEncoder _htmlEncoder;

        public ProductsController(ApplicationDbContext context, ILogger<ProductsController> logger, HtmlEncoder htmlEncoder)
        {
            _context = context;
            _logger = logger;
            _htmlEncoder = htmlEncoder;
        }

        [HttpGet]
        public async Task<IActionResult> Index(string? category = null, string? search = null)
        {
            try
            {
                var query = _context.Products.Where(p => p.IsActive);

                // Secure filtering with parameterized queries
                if (!string.IsNullOrEmpty(category))
                {
                    category = _htmlEncoder.Encode(category.Trim());
                    query = query.Where(p => p.Category == category);
                }

                if (!string.IsNullOrEmpty(search))
                {
                    search = _htmlEncoder.Encode(search.Trim());
                    query = query.Where(p => p.Name.Contains(search) || p.Description.Contains(search));
                }

                var products = await query
                    .OrderBy(p => p.Name)
                    .ToListAsync();

                ViewBag.Categories = await _context.Products
                    .Where(p => p.IsActive)
                    .Select(p => p.Category)
                    .Distinct()
                    .OrderBy(c => c)
                    .ToListAsync();

                ViewBag.CurrentCategory = category;
                ViewBag.CurrentSearch = search;

                return View(products);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading products");
                TempData["ErrorMessage"] = "Error loading products.";
                return View(new List<Product>());
            }
        }

        [HttpGet]
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            try
            {
                var product = await _context.Products
                    .Include(p => p.Reviews.Where(r => r.IsApproved))
                    .ThenInclude(r => r.User)
                    .FirstOrDefaultAsync(p => p.Id == id && p.IsActive);

                if (product == null)
                {
                    return NotFound();
                }

                var viewModel = new ProductDetailsViewModel
                {
                    Product = product,
                    AverageRating = product.Reviews.Any() ? 
                        Math.Round(product.Reviews.Average(r => r.Rating), 1) : 0,
                    ReviewCount = product.Reviews.Count(),
                    UserReview = new ProductReview { ProductId = product.Id }
                };

                return View(viewModel);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading product details for ID {ProductId}", id);
                return NotFound();
            }
        }

        [HttpPost]
        [Authorize]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddReview(ProductReview model)
        {
            if (!ModelState.IsValid)
            {
                return RedirectToAction(nameof(Details), new { id = model.ProductId });
            }

            try
            {
                var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                if (string.IsNullOrEmpty(userId))
                {
                    return Unauthorized();
                }

                // Check if user already reviewed this product
                var existingReview = await _context.ProductReviews
                    .FirstOrDefaultAsync(r => r.ProductId == model.ProductId && r.UserId == userId);

                if (existingReview != null)
                {
                    TempData["ErrorMessage"] = "You have already reviewed this product.";
                    return RedirectToAction(nameof(Details), new { id = model.ProductId });
                }

                // Sanitize input to prevent XSS
                model.Comment = _htmlEncoder.Encode(model.Comment.Trim());
                model.UserId = userId;
                model.ReviewDate = DateTime.UtcNow;
                model.IsApproved = false; // Admin approval required

                _context.ProductReviews.Add(model);
                await _context.SaveChangesAsync();

                _logger.LogInformation("Review added for product {ProductId} by user {UserId}", model.ProductId, userId);
                TempData["SuccessMessage"] = "Review submitted successfully! It will be visible after admin approval.";

                return RedirectToAction(nameof(Details), new { id = model.ProductId });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error adding review for product {ProductId}", model.ProductId);
                TempData["ErrorMessage"] = "Error submitting review. Please try again.";
                return RedirectToAction(nameof(Details), new { id = model.ProductId });
            }
        }

        [HttpPost]
        [Authorize]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddToCart(int productId, int quantity = 1)
        {
            try
            {
                var product = await _context.Products.FindAsync(productId);
                if (product == null || !product.IsActive)
                {
                    return NotFound();
                }

                if (quantity <= 0 || quantity > product.StockQuantity)
                {
                    TempData["ErrorMessage"] = "Invalid quantity selected.";
                    return RedirectToAction(nameof(Details), new { id = productId });
                }

                var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                if (string.IsNullOrEmpty(userId))
                {
                    return Unauthorized();
                }

                // For simplicity, we'll use session to store cart items
                // In production, consider using database or Redis
                var cartKey = $"cart_{userId}";
                var cart = HttpContext.Session.GetString(cartKey);
                var cartItems = string.IsNullOrEmpty(cart) ? 
                    new List<CartItem>() : 
                    System.Text.Json.JsonSerializer.Deserialize<List<CartItem>>(cart) ?? new List<CartItem>();

                var existingItem = cartItems.FirstOrDefault(c => c.ProductId == productId);
                if (existingItem != null)
                {
                    existingItem.Quantity += quantity;
                }
                else
                {
                    cartItems.Add(new CartItem
                    {
                        ProductId = productId,
                        ProductName = product.Name,
                        Price = product.Price,
                        Quantity = quantity
                    });
                }

                HttpContext.Session.SetString(cartKey, System.Text.Json.JsonSerializer.Serialize(cartItems));

                _logger.LogInformation("Product {ProductId} added to cart for user {UserId}", productId, userId);
                TempData["SuccessMessage"] = "Product added to cart successfully!";

                return RedirectToAction(nameof(Details), new { id = productId });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error adding product {ProductId} to cart", productId);
                TempData["ErrorMessage"] = "Error adding product to cart. Please try again.";
                return RedirectToAction(nameof(Details), new { id = productId });
            }
        }
    }

    // ViewModels
    public class ProductDetailsViewModel
    {
        public Product Product { get; set; } = null!;
        public double AverageRating { get; set; }
        public int ReviewCount { get; set; }
        public ProductReview UserReview { get; set; } = null!;
    }

    public class CartItem
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; } = string.Empty;
        public decimal Price { get; set; }
        public int Quantity { get; set; }
        public decimal Total => Price * Quantity;
    }
}