# ASP.NET Core Secure Shopping Application

## Overview
This application demonstrates comprehensive security implementation in ASP.NET Core MVC, addressing:

- ✅ Secure Input Validation and Output Encoding
- ✅ SQL Injection Prevention
- ✅ Authentication and Authorization
- ✅ Secure User Registration and Login
- ✅ Secure Logout

## Features
- Role-based access control (Admin/Customer)
- Strong password requirements
- Account lockout protection
- XSS prevention with HTML encoding
- CSRF protection
- Secure session management
- Security headers implementation

## Setup Instructions
1. Clone or extract the project
2. Run `dotnet restore`
3. Run `dotnet build`
4. Run `dotnet run`
5. Navigate to `https://localhost:5001`

## Demo Accounts
- **Admin**: admin@secureshop.com / Admin123!@#
- **Customer**: Register a new account

## Security Features
- All user inputs are validated and sanitized
- Parameterized queries prevent SQL injection
- HTML encoding prevents XSS attacks
- Role-based authorization protects admin areas
- Strong authentication with lockout protection
- Secure logout clears all session data
