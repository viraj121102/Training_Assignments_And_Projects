﻿namespace Lambda_Expression
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            int[] myNum = { 10, 20, 30, 40,31,345 };

            //   var evenNumbers = myNum.Where(n => n % 2 == 0);
            //   foreach (var item in evenNumbers)
            //   {
            //       Console.WriteLine(item);
            //   }

              var numbers = new[] { 5, 1, 4, 2 };
            //   var sortedNumbers = numbers.OrderBy(n => n);

            //   foreach (var item in sortedNumbers)
            //   {
            //       Console.WriteLine(item);
            //   }
            //   var sum = numbers.Sum();
            //   Console.WriteLine(sum);

            //   var min=numbers.Min();
            //Console.WriteLine(min);
            //var set1 = new[] { 1, 2, 3 };
            //var set2 = new[] { 3, 4, 5 };
            //var unionSet = set1.Union(set2);

            //foreach (var item in unionSet) {   Console.WriteLine(item); }
            var people = new[]
  {
    new { Name = "John", Age = 30 },
    new { Name = "Alice", Age = 25 },
    new { Name = "John", Age = 22 }
};
            var sortedPeople = people.OrderBy(p => p.Name).ThenBy(p => p.Age);

            foreach (var person in sortedPeople)
            {
                Console.WriteLine(person.Name);
            }
            var hasEven = numbers.Any(n => n % 2 == 0);
            Console.WriteLine(hasEven);
        }
    }
}
